var Observable = require("data/observable").Observable;
var cameraModule = require("camera");

function getMessage(counter) {
    if (counter <= 0) {
        return "Hoorraaay! You unlocked the NativeScript clicker achievement!";
    } else {
        return counter + " taps left";
    }
}

function createViewModel() {
    var viewModel = new Observable();
    viewModel.counter = 42;
    viewModel.message = getMessage(viewModel.counter);

    viewModel.onTap = function() {
          cameraModule.takePicture({
            width: 400,
            height: 400,
            keepAspectRatio: true,
            saveToGallery: true
        }).then(picture => {
           console.log("Picture should be in gallery now");
        }, () => {
            console.log("Picture Failed");
        });

    }

    return viewModel;
}

exports.createViewModel = createViewModel;