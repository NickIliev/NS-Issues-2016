//
//  TNSWidgets.h
//  TNSWidgets
//
//  Created by Panayot Cankov on 4/27/16.
//  Copyright © 2016 Telerik A D. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TNSWidgets.
FOUNDATION_EXPORT double TNSWidgetsVersionNumber;

//! Project version string for TNSWidgets.
FOUNDATION_EXPORT const unsigned char TNSWidgetsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TNSWidgets/PublicHeader.h>

#import "UIImage+TNSBlocks.h"
#import "TNSLabel.h"
