import {DataItem} from './dataItem';

export var DATAITEMS: DataItem[] = [
    { "id": 1, "name": "Item 1", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 2, "name": "Item 2", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 3, "name": "Item 3", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 4, "name": "Item 4", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 5, "name": "Item 5", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 6, "name": "Item 6", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 7, "name": "Item 7", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 8, "name": "Item 8", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 9, "name": "Item 9", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
    { "id": 10, "name": "Item 10", "description":"This is item description.", "title": "This is item Title", "text": "This is item Text",  "image": "This is item Image" },
]