var DataItem = (function () {
    function DataItem(id, name, description, title, text, image) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.title = title;
        this.text = text;
        this.image = image;
    }
    return DataItem;
}());
exports.DataItem = DataItem;
