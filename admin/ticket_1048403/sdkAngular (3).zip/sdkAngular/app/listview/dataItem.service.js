var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var mock_dataItems_1 = require("./mock-dataItems");
var dataItem_1 = require("./dataItem");
var namesAndEmails = require("../listview/NamesAndEmails.json");
var posts = require("../listview/posts.json");
var DataItemService = (function () {
    function DataItemService() {
    }
    DataItemService.prototype.getDataItems = function () {
        return mock_dataItems_1.DATAITEMS;
    };
    DataItemService.prototype.getIdenticalDataItems = function (size) {
        var result = new Array();
        for (var i = 0; i < size; i++) {
            result.push(new dataItem_1.DataItem(i, "Item " + i, "This is item description."));
        }
        return result;
    };
    DataItemService.prototype.getPersonDataItems = function () {
        var result = new Array();
        for (var i = 0; i < namesAndEmails.names.length; i++) {
            result.push(new dataItem_1.DataItem(i, namesAndEmails.names[i], "This is item description"));
        }
        return result;
    };
    DataItemService.prototype.getNameEmailDataItems = function () {
        var result = new Array();
        for (var i = 0; i < namesAndEmails.names.length; i++) {
            result.push(new dataItem_1.DataItem(i, namesAndEmails.names[i], namesAndEmails.emails[i]));
        }
        return result;
    };
    DataItemService.prototype.getPostDataItems = function () {
        var result = new Array();
        for (var i = 0; i < posts.names.length; i++) {
            result.push(new dataItem_1.DataItem(i, posts.names[i], "This is item description", posts.titles[i], posts.text[i]));
        }
        return result;
    };
    DataItemService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], DataItemService);
    return DataItemService;
}());
exports.DataItemService = DataItemService;
