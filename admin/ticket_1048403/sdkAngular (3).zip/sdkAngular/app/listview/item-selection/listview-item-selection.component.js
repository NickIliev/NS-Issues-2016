var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var observable_array_1 = require("data/observable-array");
var dataItem_service_1 = require("../dataItem.service");
var namesAndEmails = require("../../listview/NamesAndEmails.json");
var ListViewItemSelectionComponent = (function () {
    function ListViewItemSelectionComponent(_dataItemService) {
        this._dataItemService = _dataItemService;
    }
    Object.defineProperty(ListViewItemSelectionComponent.prototype, "dataItems", {
        get: function () {
            return this._dataItems;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ListViewItemSelectionComponent.prototype, "selectedItems", {
        get: function () {
            return this._selectedItems;
        },
        enumerable: true,
        configurable: true
    });
    ListViewItemSelectionComponent.prototype.ngOnInit = function () {
        this._dataItems = new observable_array_1.ObservableArray(this._dataItemService.getNameEmailDataItems());
        this._selectedItems = "No Selected items.";
    };
    ListViewItemSelectionComponent.prototype.onItemSelected = function (args) {
        var listview = args.object;
        var selectedItems = listview.getSelectedItems();
        var selectedTitles = "Selected items: ";
        for (var i = 0; i < selectedItems.length; i++) {
            selectedTitles += selectedItems[i].name;
            if (i < selectedItems.length - 1) {
                selectedTitles += ", ";
            }
        }
        this._selectedItems = selectedTitles;
        console.log("Item selected.");
    };
    ListViewItemSelectionComponent.prototype.onItemDeselected = function (args) {
        var listview = args.object;
        var selectedItems = listview.getSelectedItems();
        if (selectedItems.length > 0) {
            var selectedTitles = "Selected items: ";
            for (var i = 0; i < selectedItems.length; i++) {
                selectedTitles += selectedItems[i].name;
                if (i < selectedItems.length - 1) {
                    selectedTitles += ", ";
                }
            }
            this._selectedItems = selectedTitles;
        }
        else {
            this._selectedItems = "No Selected items.";
        }
        console.log("Item deselected.");
    };
    ListViewItemSelectionComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "listview-item-selection",
            providers: [dataItem_service_1.DataItemService],
            templateUrl: "listview-item-selection.component.html",
            styleUrls: ["listview-item-selection.component.css"]
        }), 
        __metadata('design:paramtypes', [dataItem_service_1.DataItemService])
    ], ListViewItemSelectionComponent);
    return ListViewItemSelectionComponent;
}());
exports.ListViewItemSelectionComponent = ListViewItemSelectionComponent;
// << angular-listview-selection-component 
