var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var observable_array_1 = require("data/observable-array");
var dataItem_1 = require("../dataItem");
var listViewModule = require("nativescript-telerik-ui-pro/listview");
var Application = require("application");
var Timer = require("timer");
var posts = require("../../listview/posts.json");
var ListViewLoadOnDemandComponent = (function () {
    function ListViewLoadOnDemandComponent(_changeDetectionRef) {
        this._changeDetectionRef = _changeDetectionRef;
    }
    ListViewLoadOnDemandComponent.prototype.ngOnInit = function () {
        this.layout = new listViewModule.ListViewLinearLayout();
        this.layout.scrollDirection = "Vertical";
        this.layout.itemHeight = 120;
        this.initDataItems();
        this._changeDetectionRef.detectChanges();
    };
    Object.defineProperty(ListViewLoadOnDemandComponent.prototype, "dataItems", {
        get: function () {
            return this._dataItems;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ListViewLoadOnDemandComponent.prototype, "layout", {
        get: function () {
            return this._layout;
        },
        set: function (value) {
            this._layout = value;
        },
        enumerable: true,
        configurable: true
    });
    ListViewLoadOnDemandComponent.prototype.onLoadMoreItemsRequested = function (args) {
        var that = new WeakRef(this);
        Timer.setTimeout(function () {
            var listView = args.object;
            var initialNumberOfItems = that.get()._numberOfAddedItems;
            for (var i = that.get()._numberOfAddedItems; i < initialNumberOfItems + 2; i++) {
                if (i > posts.names.length - 1) {
                    listView.loadOnDemandMode = listViewModule.ListViewLoadOnDemandMode[listViewModule.ListViewLoadOnDemandMode.None];
                    break;
                }
                var imageUri = Application.android ? posts.images[i].toLowerCase() : posts.images[i];
                that.get()._dataItems.push(new dataItem_1.DataItem(i, posts.names[i], "This is item description", posts.titles[i], posts.text[i], "res://" + imageUri));
                that.get()._numberOfAddedItems++;
            }
            listView.notifyLoadOnDemandFinished();
        }, 1000);
        args.returnValue = true;
    };
    ListViewLoadOnDemandComponent.prototype.initDataItems = function () {
        this._dataItems = new observable_array_1.ObservableArray();
        this._numberOfAddedItems = 0;
        for (var i = 0; i < posts.names.length - 15; i++) {
            this._numberOfAddedItems++;
            if (Application.android) {
                this._dataItems.push(new dataItem_1.DataItem(i, posts.names[i], "This is item description", posts.titles[i], posts.text[i], "res://" + posts.images[i].toLowerCase()));
            }
            else {
                this._dataItems.push(new dataItem_1.DataItem(i, posts.names[i], "This is item description", posts.titles[i], posts.text[i], "res://" + posts.images[i]));
            }
        }
    };
    ListViewLoadOnDemandComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "listview-load-on-demand",
            templateUrl: "listview-load-on-demand.component.html",
            styleUrls: ["listview-load-on-demand.component.css"]
        }), 
        __metadata('design:paramtypes', [core_1.ChangeDetectorRef])
    ], ListViewLoadOnDemandComponent);
    return ListViewLoadOnDemandComponent;
}());
exports.ListViewLoadOnDemandComponent = ListViewLoadOnDemandComponent;
// << angular-listview-load-on-demand-code 
