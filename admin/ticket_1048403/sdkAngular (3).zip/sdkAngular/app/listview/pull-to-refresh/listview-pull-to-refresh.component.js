var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var observable_array_1 = require("data/observable-array");
var dataItem_1 = require("../dataItem");
var listViewModule = require("nativescript-telerik-ui-pro/listview");
var Application = require("application");
var Timer = require("timer");
var posts = require("../../listview/posts.json");
var ListViewPullToRefreshComponent = (function () {
    function ListViewPullToRefreshComponent(_changeDetectionRef) {
        this._changeDetectionRef = _changeDetectionRef;
    }
    ListViewPullToRefreshComponent.prototype.ngOnInit = function () {
        this.layout = new listViewModule.ListViewLinearLayout();
        this.layout.scrollDirection = "Vertical";
        this.initDataItems();
        this._changeDetectionRef.detectChanges();
    };
    Object.defineProperty(ListViewPullToRefreshComponent.prototype, "dataItems", {
        get: function () {
            return this._dataItems;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ListViewPullToRefreshComponent.prototype, "layout", {
        get: function () {
            return this._layout;
        },
        set: function (value) {
            this._layout = value;
        },
        enumerable: true,
        configurable: true
    });
    ListViewPullToRefreshComponent.prototype.onPullToRefreshInitiated = function (args) {
        var that = new WeakRef(this);
        Timer.setTimeout(function () {
            var initialNumberOfItems = that.get()._numberOfAddedItems;
            for (var i = that.get()._numberOfAddedItems; i < initialNumberOfItems + 2; i++) {
                if (i > posts.names.length - 1) {
                    break;
                }
                var imageUri = Application.android ? posts.images[i].toLowerCase() : posts.images[i];
                that.get()._dataItems.splice(0, 0, new dataItem_1.DataItem(i, posts.names[i], "This is item description", posts.titles[i], posts.text[i], "res://" + imageUri));
                that.get()._numberOfAddedItems++;
            }
            var listView = args.object;
            listView.notifyPullToRefreshFinished();
        }, 1000);
    };
    ListViewPullToRefreshComponent.prototype.initDataItems = function () {
        this._dataItems = new observable_array_1.ObservableArray();
        this._numberOfAddedItems = 0;
        for (var i = 0; i < posts.names.length - 15; i++) {
            this._numberOfAddedItems++;
            if (Application.android) {
                this._dataItems.push(new dataItem_1.DataItem(i, posts.names[i], "This is item description", posts.titles[i], posts.text[i], "res://" + posts.images[i].toLowerCase()));
            }
            else {
                this._dataItems.push(new dataItem_1.DataItem(i, posts.names[i], "This is item description", posts.titles[i], posts.text[i], "res://" + posts.images[i]));
            }
        }
    };
    ListViewPullToRefreshComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "listview-pull-to-refresh",
            templateUrl: "listview-pull-to-refresh.component.html",
            styleUrls: ["listview-pull-to-refresh.component.css"]
        }), 
        __metadata('design:paramtypes', [core_1.ChangeDetectorRef])
    ], ListViewPullToRefreshComponent);
    return ListViewPullToRefreshComponent;
}());
exports.ListViewPullToRefreshComponent = ListViewPullToRefreshComponent;
// << angular-listview-pull-to-refresh-code 
