var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var observable_array_1 = require("data/observable-array");
var dataItem_service_1 = require("../dataItem.service");
var ListViewGettingStartedComponent = (function () {
    function ListViewGettingStartedComponent(_dataItemService) {
        this._dataItemService = _dataItemService;
    }
    Object.defineProperty(ListViewGettingStartedComponent.prototype, "dataItems", {
        get: function () {
            return this._dataItems;
        },
        enumerable: true,
        configurable: true
    });
    ListViewGettingStartedComponent.prototype.ngOnInit = function () {
        this._dataItems = new observable_array_1.ObservableArray(this._dataItemService.getDataItems());
    };
    ListViewGettingStartedComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "listview-getting-started",
            providers: [dataItem_service_1.DataItemService],
            templateUrl: "listview-getting-started.component.html",
            styleUrls: ["listview-getting-started.component.css"]
        }), 
        __metadata('design:paramtypes', [dataItem_service_1.DataItemService])
    ], ListViewGettingStartedComponent);
    return ListViewGettingStartedComponent;
}());
exports.ListViewGettingStartedComponent = ListViewGettingStartedComponent;
// << listview-getting-started-angular 
