var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var page_1 = require("ui/page");
var sidedrawer_1 = require('nativescript-telerik-ui-pro/sidedrawer');
var angular_1 = require("nativescript-telerik-ui-pro/sidedrawer/angular");
var observable_array_1 = require("data/observable-array");
var data_service_1 = require("../data.service");
var DependencyObservableModule = require("ui/core/dependency-observable");
var ProxyModule = require("ui/core/proxy");
var SideDrawerPositionComponent = (function (_super) {
    __extends(SideDrawerPositionComponent, _super);
    function SideDrawerPositionComponent(page, _dataService, _changeDetectionRef) {
        _super.call(this);
        this.page = page;
        this._dataService = _dataService;
        this._changeDetectionRef = _changeDetectionRef;
    }
    SideDrawerPositionComponent.prototype.ngOnInit = function () {
        this.locations = new observable_array_1.ObservableArray(this._dataService.getDrawerLocations());
        this.currentLocation = sidedrawer_1.SideDrawerLocation.Left;
        this.selectedLocationIndex = 0;
    };
    // << sidedrawer-angular-position-code
    SideDrawerPositionComponent.prototype.ngAfterViewInit = function () {
        this.drawer = this.drawerComponent.sideDrawer;
        this._changeDetectionRef.detectChanges();
    };
    Object.defineProperty(SideDrawerPositionComponent.prototype, "selectedLocationIndex", {
        get: function () {
            return this._getValue(SideDrawerPositionComponent.selectedLocationIndexProperty);
        },
        set: function (value) {
            this._setValue(SideDrawerPositionComponent.selectedLocationIndexProperty, value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SideDrawerPositionComponent.prototype, "locations", {
        get: function () {
            return this._getValue(SideDrawerPositionComponent.locationsProperty);
        },
        set: function (value) {
            this._setValue(SideDrawerPositionComponent.locationsProperty, value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SideDrawerPositionComponent.prototype, "currentLocation", {
        get: function () {
            return this._getValue(SideDrawerPositionComponent.currentLocationroperty);
        },
        set: function (value) {
            this._setValue(SideDrawerPositionComponent.currentLocationroperty, value);
        },
        enumerable: true,
        configurable: true
    });
    SideDrawerPositionComponent.onSelectedLocationIndexPropertyChanged = function (args) {
        var drawee = args.object;
        drawee.onSelectedLocationIndexChanged(args);
    };
    SideDrawerPositionComponent.prototype.onSelectedLocationIndexChanged = function (args) {
        this.currentLocation = this.locations.getItem(this.selectedLocationIndex);
    };
    SideDrawerPositionComponent.prototype.onOpenDrawerTap = function () {
        this.drawer.showDrawer();
    };
    SideDrawerPositionComponent.selectedLocationIndexProperty = new DependencyObservableModule.Property("selectedLocationIndex", "SidedrawerPositionComponent", new ProxyModule.PropertyMetadata(undefined, DependencyObservableModule.PropertyMetadataSettings.None, SideDrawerPositionComponent.onSelectedLocationIndexPropertyChanged));
    SideDrawerPositionComponent.locationsProperty = new DependencyObservableModule.Property("locations", "SidedrawerPositionComponent", new ProxyModule.PropertyMetadata(undefined, DependencyObservableModule.PropertyMetadataSettings.None));
    SideDrawerPositionComponent.currentLocationroperty = new DependencyObservableModule.Property("currentLocation", "SidedrawerPositionComponent", new ProxyModule.PropertyMetadata(undefined, DependencyObservableModule.PropertyMetadataSettings.None));
    __decorate([
        core_1.ViewChild(angular_1.RadSideDrawerComponent), 
        __metadata('design:type', angular_1.RadSideDrawerComponent)
    ], SideDrawerPositionComponent.prototype, "drawerComponent", void 0);
    SideDrawerPositionComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "sidedrawer-position",
            providers: [data_service_1.DataService],
            templateUrl: 'position.component.html',
            styleUrls: ["position.component.css"]
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, data_service_1.DataService, core_1.ChangeDetectorRef])
    ], SideDrawerPositionComponent);
    return SideDrawerPositionComponent;
}(DependencyObservableModule.DependencyObservable));
exports.SideDrawerPositionComponent = SideDrawerPositionComponent;
