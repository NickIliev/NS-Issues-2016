var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var page_1 = require("ui/page");
var ObservableModule = require("data/observable");
var angular_1 = require("nativescript-telerik-ui-pro/sidedrawer/angular");
var SideDrawerGettingStartedComponent = (function (_super) {
    __extends(SideDrawerGettingStartedComponent, _super);
    function SideDrawerGettingStartedComponent(page, _changeDetectionRef) {
        _super.call(this);
        this.page = page;
        this._changeDetectionRef = _changeDetectionRef;
    }
    SideDrawerGettingStartedComponent.prototype.ngAfterViewInit = function () {
        this.drawer = this.drawerComponent.sideDrawer;
        this._changeDetectionRef.detectChanges();
    };
    SideDrawerGettingStartedComponent.prototype.ngOnInit = function () {
        this.set("mainContentText", "SideDrawer for NativeScript can be easily setup in the XML definition of your page by defining main- and drawer-content. The component"
            + " has a default transition and position and also exposes notifications related to changes in its state. Swipe from left to open side drawer.");
    };
    SideDrawerGettingStartedComponent.prototype.openDrawer = function () {
        this.drawer.showDrawer();
    };
    __decorate([
        core_1.ViewChild(angular_1.RadSideDrawerComponent), 
        __metadata('design:type', angular_1.RadSideDrawerComponent)
    ], SideDrawerGettingStartedComponent.prototype, "drawerComponent", void 0);
    SideDrawerGettingStartedComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "sidedrawer-getting-started",
            templateUrl: 'getting-started.component.html',
            styleUrls: ['getting-started.component.css']
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, core_1.ChangeDetectorRef])
    ], SideDrawerGettingStartedComponent);
    return SideDrawerGettingStartedComponent;
}(ObservableModule.Observable));
exports.SideDrawerGettingStartedComponent = SideDrawerGettingStartedComponent;
