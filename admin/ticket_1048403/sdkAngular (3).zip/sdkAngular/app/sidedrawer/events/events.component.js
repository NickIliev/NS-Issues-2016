var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var page_1 = require("ui/page");
var sideDrawerModule = require('nativescript-telerik-ui-pro/sidedrawer');
var angular_1 = require("nativescript-telerik-ui-pro/sidedrawer/angular");
// >> sidedrawer-angular-callbacks-definition
var SideDrawerEventsComponent = (function () {
    function SideDrawerEventsComponent(_page, _changeDetectionRef) {
        this._page = _page;
        this._changeDetectionRef = _changeDetectionRef;
        this._page.on("loaded", this.onLoaded, this);
    }
    SideDrawerEventsComponent.prototype.ngAfterViewInit = function () {
        this.drawer = this.drawerComponent.sideDrawer;
        this._changeDetectionRef.detectChanges();
    };
    SideDrawerEventsComponent.prototype.ngOnInit = function () {
    };
    SideDrawerEventsComponent.prototype.onLoaded = function (args) {
        this._sideDrawerTransition = new sideDrawerModule.PushTransition();
    };
    Object.defineProperty(SideDrawerEventsComponent.prototype, "sideDrawerTransition", {
        get: function () {
            return this._sideDrawerTransition;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SideDrawerEventsComponent.prototype, "currentNotification", {
        get: function () {
            return this._currentNotification;
        },
        enumerable: true,
        configurable: true
    });
    SideDrawerEventsComponent.prototype.openDrawer = function () {
        this.drawer.showDrawer();
    };
    SideDrawerEventsComponent.prototype.onDrawerOpening = function () {
        console.log("Drawer opening");
        this._currentNotification = "Drawer opening";
    };
    SideDrawerEventsComponent.prototype.onDrawerOpened = function () {
        console.log("Drawer opened");
        this._currentNotification = "Drawer opened";
    };
    SideDrawerEventsComponent.prototype.onDrawerClosing = function () {
        console.log("Drawer closing");
        this._currentNotification = "Drawer closing";
    };
    SideDrawerEventsComponent.prototype.onDrawerClosed = function () {
        console.log("Drawer closed");
        this._currentNotification = "Drawer closed";
    };
    __decorate([
        core_1.ViewChild(angular_1.RadSideDrawerComponent), 
        __metadata('design:type', angular_1.RadSideDrawerComponent)
    ], SideDrawerEventsComponent.prototype, "drawerComponent", void 0);
    SideDrawerEventsComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "sidedrawer-events",
            templateUrl: 'events.component.html',
            styleUrls: ['events.component.css']
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, core_1.ChangeDetectorRef])
    ], SideDrawerEventsComponent);
    return SideDrawerEventsComponent;
}());
exports.SideDrawerEventsComponent = SideDrawerEventsComponent;
// << sidedrawer-angular-callbacks-definition 
