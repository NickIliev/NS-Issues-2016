var sidedrawer_1 = require('nativescript-telerik-ui-pro/sidedrawer');
exports.LOCATIONS = [
    sidedrawer_1.SideDrawerLocation.Left,
    sidedrawer_1.SideDrawerLocation.Top,
    sidedrawer_1.SideDrawerLocation.Right,
    sidedrawer_1.SideDrawerLocation.Bottom
];
