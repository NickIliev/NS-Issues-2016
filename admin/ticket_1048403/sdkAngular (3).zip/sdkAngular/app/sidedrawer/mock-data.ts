import { SideDrawerLocation } from 'nativescript-telerik-ui-pro/sidedrawer';

export var LOCATIONS: SideDrawerLocation[] = [
    SideDrawerLocation.Left,
    SideDrawerLocation.Top,
    SideDrawerLocation.Right,
    SideDrawerLocation.Bottom
]