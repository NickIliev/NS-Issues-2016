// >> chart-angular-person
export class Person {
    constructor(public Age?: number, public Salary?: number, public Spendings?: number, public Savings?: number, public Impact?: number) {
    }
}
// << chart-angular-person