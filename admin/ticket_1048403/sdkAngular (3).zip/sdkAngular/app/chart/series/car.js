// >> chart-angular-car
var Car = (function () {
    function Car(Brand, Amount) {
        this.Brand = Brand;
        this.Amount = Amount;
    }
    return Car;
}());
exports.Car = Car;
// << chart-angular-car 
