// >> chart-angular-country
var Country = (function () {
    function Country(Country, Amount, SecondVal, ThirdVal, Impact, Year) {
        this.Country = Country;
        this.Amount = Amount;
        this.SecondVal = SecondVal;
        this.ThirdVal = ThirdVal;
        this.Impact = Impact;
        this.Year = Year;
    }
    return Country;
}());
exports.Country = Country;
// << chart-angular-country 
