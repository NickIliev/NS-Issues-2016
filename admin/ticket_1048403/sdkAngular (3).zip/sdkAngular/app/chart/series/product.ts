// >> chart-angular-product
export class Product {
    constructor(public Name?: string, public High?: number, public Low?: number) {
    }
}
// << chart-angular-product