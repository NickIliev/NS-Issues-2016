// >> chart-angular-currency
export class Currency {
    constructor(public Date?: string, public Open?: number, public Close?: number, public Low?: number, public High?: number) {
    }
}
// << chart-angular-currency