// >> chart-angular-currency
var Currency = (function () {
    function Currency(Date, Open, Close, Low, High) {
        this.Date = Date;
        this.Open = Open;
        this.Close = Close;
        this.Low = Low;
        this.High = High;
    }
    return Currency;
}());
exports.Currency = Currency;
// << chart-angular-currency 
