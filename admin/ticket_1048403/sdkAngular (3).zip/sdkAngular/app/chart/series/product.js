// >> chart-angular-product
var Product = (function () {
    function Product(Name, High, Low) {
        this.Name = Name;
        this.High = High;
        this.Low = Low;
    }
    return Product;
}());
exports.Product = Product;
// << chart-angular-product 
