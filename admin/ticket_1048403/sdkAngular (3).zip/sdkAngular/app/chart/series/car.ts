// >> chart-angular-car
export class Car {
    constructor(public Brand?: string, public Amount?: number) {
    }
}
// << chart-angular-car