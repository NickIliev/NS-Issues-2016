var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var options_service_1 = require("../../../navigation/options/options.service");
var options_example_base_1 = require("../../../options-example-base");
var core_1 = require("@angular/core");
var router_1 = require('@angular/router');
var page_1 = require("ui/page");
var applicationModule = require("application");
var data_service_1 = require('../data.service');
var observable_array_1 = require("data/observable-array");
var ChartSeriesStackedBarComponent = (function (_super) {
    __extends(ChartSeriesStackedBarComponent, _super);
    function ChartSeriesStackedBarComponent(_page, _optionsService, _router, _changeDetectionRef, _dataService) {
        _super.call(this);
        this._page = _page;
        this._optionsService = _optionsService;
        this._router = _router;
        this._changeDetectionRef = _changeDetectionRef;
        this._dataService = _dataService;
        if (applicationModule.ios) {
            this._page.on("navigatingTo", this.onNavigatingTo, this);
            this._optionsParamName = "stackMode";
            this._optionsService.paramName = this._optionsParamName;
            this.router = _router;
            this._optionsItems = ["Stack", "Stack 100", "None"];
            this.navigationParameters = { selectedIndex: 1, paramName: this._optionsParamName, items: this._optionsItems };
        }
    }
    Object.defineProperty(ChartSeriesStackedBarComponent.prototype, "categoricalSource", {
        get: function () {
            return this._categoricalSource;
        },
        enumerable: true,
        configurable: true
    });
    ChartSeriesStackedBarComponent.prototype.ngOnInit = function () {
        this._categoricalSource = new observable_array_1.ObservableArray(this._dataService.getCategoricalSource());
        this.onStack100ModeSelected();
    };
    ChartSeriesStackedBarComponent.prototype.ngAfterViewInit = function () {
        this._changeDetectionRef.detectChanges();
    };
    ChartSeriesStackedBarComponent.prototype.onNoneStackModeSelected = function () {
        this.set("stackMode", "None");
    };
    ChartSeriesStackedBarComponent.prototype.onStackModeSelected = function () {
        this.set("stackMode", "Stack");
    };
    ChartSeriesStackedBarComponent.prototype.onStack100ModeSelected = function () {
        this.set("stackMode", "Stack100");
    };
    ChartSeriesStackedBarComponent.prototype.onNavigatingTo = function (args) {
        if (args.isBackNavigation) {
            if (this._optionsService.paramName === this._optionsParamName) {
                this.navigationParameters.selectedIndex = this._optionsItems.indexOf(this._optionsService.paramValue);
                switch (this._optionsService.paramValue) {
                    case "Stack 100":
                        this.onStack100ModeSelected();
                        break;
                    case "Stack":
                        this.onStackModeSelected();
                        break;
                    case "None":
                        this.onNoneStackModeSelected();
                        break;
                    default:
                        break;
                }
            }
        }
    };
    ChartSeriesStackedBarComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'chart-series-stacked-bar',
            providers: [data_service_1.DataService],
            templateUrl: 'chart-series-stacked-bar.component.html'
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, options_service_1.OptionsService, router_1.Router, core_1.ChangeDetectorRef, data_service_1.DataService])
    ], ChartSeriesStackedBarComponent);
    return ChartSeriesStackedBarComponent;
}(options_example_base_1.OptionsExampleBase));
exports.ChartSeriesStackedBarComponent = ChartSeriesStackedBarComponent;
