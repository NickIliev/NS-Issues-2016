// >> chart-angular-person
var Person = (function () {
    function Person(Age, Salary, Spendings, Savings, Impact) {
        this.Age = Age;
        this.Salary = Salary;
        this.Spendings = Spendings;
        this.Savings = Savings;
        this.Impact = Impact;
    }
    return Person;
}());
exports.Person = Person;
// << chart-angular-person 
