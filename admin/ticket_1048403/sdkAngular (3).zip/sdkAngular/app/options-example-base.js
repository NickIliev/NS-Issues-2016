var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var frameModule = require("ui/frame");
var ObservableModule = require("data/observable");
var OptionsExampleBase = (function (_super) {
    __extends(OptionsExampleBase, _super);
    function OptionsExampleBase() {
        _super.call(this);
    }
    OptionsExampleBase.prototype.onOptionsTapped = function () {
        this.router.navigate(['/options'], { queryParams: { selectedIndex: this.navigationParameters.selectedIndex, paramName: this.navigationParameters.paramName, items: this.navigationParameters.items } });
    };
    OptionsExampleBase.prototype.onNavigationButtonTap = function () {
        frameModule.topmost().goBack();
    };
    return OptionsExampleBase;
}(ObservableModule.Observable));
exports.OptionsExampleBase = OptionsExampleBase;
