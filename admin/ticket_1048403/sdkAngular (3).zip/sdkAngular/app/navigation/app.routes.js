var router_1 = require("nativescript-angular/router");
var examples_list_component_1 = require("./examples-list/examples-list.component");
var example_component_1 = require("./example/example.component");
var options_component_1 = require("./options/options.component");
var routes = [
    { path: "", redirectTo: "/examples-depth-1/root/root", terminal: true },
    { path: "examples-depth-1/:parentTitle/:tappedTitle", component: examples_list_component_1.ExamplesListDepth1Component },
    { path: "examples-depth-2/:parentTitle/:tappedTitle", component: examples_list_component_1.ExamplesListDepth2Component },
    { path: "examples-depth-3/:parentTitle/:tappedTitle", component: examples_list_component_1.ExamplesListDepth3Component },
    { path: "example/:parentTitle/:tappedTitle", component: example_component_1.ExampleComponent },
    { path: "options", component: options_component_1.OptionsComponent }
];
exports.AppPageRouterOutletRouterProviders = [
    router_1.nsProvideRouter(routes, { enableTracing: false })
];
