var ExampleItem = (function () {
    function ExampleItem(title, path, subItems) {
        this.title = title;
        this.path = path;
        this.subItems = subItems;
    }
    return ExampleItem;
}());
exports.ExampleItem = ExampleItem;
