var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var exampleItemService_service_1 = require("../exampleItemService.service");
var FrameModule = require("ui/frame");
var router_1 = require('@angular/router');
var ExamplesListDepth1Component = (function () {
    function ExamplesListDepth1Component(_router, _route, _exampleItemsService) {
        this._router = _router;
        this._route = _route;
        this._exampleItemsService = _exampleItemsService;
    }
    ExamplesListDepth1Component.prototype.ngOnInit = function () {
        var _this = this;
        this._sub = this._route.params.subscribe(function (params) {
            var parentTitle = params['parentTitle'];
            var tappedTitle = params['tappedTitle'];
            _this.hasBack = false;
            _this._currentExample = _this._exampleItemsService.getParentExampleItem(0);
        });
    };
    ExamplesListDepth1Component.prototype.ngOnDestroy = function () {
        this._sub.unsubscribe();
    };
    Object.defineProperty(ExamplesListDepth1Component.prototype, "currentExample", {
        get: function () {
            return this._currentExample;
        },
        set: function (value) {
            this._currentExample = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ExamplesListDepth1Component.prototype, "hasBack", {
        get: function () {
            return this._hasBack;
        },
        set: function (value) {
            this._hasBack = value;
        },
        enumerable: true,
        configurable: true
    });
    ExamplesListDepth1Component.prototype.onNavigationItemTap = function (args) {
        var itemIndex = args.itemIndex;
        var tappedItem = this._currentExample.subItems[itemIndex];
        if (tappedItem.subItems.length === 0) {
            this._router.navigate(['/example', this._currentExample.title, tappedItem.title]);
        }
        else {
            this._router.navigate(['/examples-depth-2', this._currentExample.title, tappedItem.title]);
        }
    };
    ExamplesListDepth1Component.prototype.onNavigationButtonTap = function () {
        FrameModule.topmost().goBack();
    };
    ExamplesListDepth1Component = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "examples",
            templateUrl: "examples-list.component.html",
            styleUrls: ["examples-list.component.css"]
        }), 
        __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, exampleItemService_service_1.ExampleItemService])
    ], ExamplesListDepth1Component);
    return ExamplesListDepth1Component;
}());
exports.ExamplesListDepth1Component = ExamplesListDepth1Component;
var ExamplesListDepth2Component = (function () {
    function ExamplesListDepth2Component(_router, _route, _exampleItemsService) {
        this._router = _router;
        this._route = _route;
        this._exampleItemsService = _exampleItemsService;
    }
    ExamplesListDepth2Component.prototype.ngOnInit = function () {
        var _this = this;
        this._sub = this._route.params.subscribe(function (params) {
            var parentTitle = params['parentTitle'];
            var tappedTitle = params['tappedTitle'];
            _this.hasBack = true;
            _this._currentExample = _this._exampleItemsService.getChildExampleItem(parentTitle, tappedTitle, _this._exampleItemsService.getAllExampleItems());
        });
    };
    ExamplesListDepth2Component.prototype.ngOnDestroy = function () {
        this._sub.unsubscribe();
    };
    Object.defineProperty(ExamplesListDepth2Component.prototype, "currentExample", {
        get: function () {
            return this._currentExample;
        },
        set: function (value) {
            this._currentExample = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ExamplesListDepth2Component.prototype, "hasBack", {
        get: function () {
            return this._hasBack;
        },
        set: function (value) {
            this._hasBack = value;
        },
        enumerable: true,
        configurable: true
    });
    ExamplesListDepth2Component.prototype.onNavigationItemTap = function (args) {
        var itemIndex = args.itemIndex;
        var tappedItem = this._currentExample.subItems[itemIndex];
        if (tappedItem.subItems.length === 0) {
            this._router.navigate(['/example', this._currentExample.title, tappedItem.title]);
        }
        else {
            this._router.navigate(['/examples-depth-3', this._currentExample.title, tappedItem.title]);
        }
    };
    ExamplesListDepth2Component.prototype.onNavigationButtonTap = function () {
        FrameModule.topmost().goBack();
    };
    ExamplesListDepth2Component = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "examples-depth-2",
            templateUrl: "examples-list.component.html",
            styleUrls: ["examples-list.component.css"]
        }), 
        __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, exampleItemService_service_1.ExampleItemService])
    ], ExamplesListDepth2Component);
    return ExamplesListDepth2Component;
}());
exports.ExamplesListDepth2Component = ExamplesListDepth2Component;
var ExamplesListDepth3Component = (function () {
    function ExamplesListDepth3Component(_router, _route, _exampleItemsService) {
        this._router = _router;
        this._route = _route;
        this._exampleItemsService = _exampleItemsService;
    }
    ExamplesListDepth3Component.prototype.ngOnInit = function () {
        var _this = this;
        this._sub = this._route.params.subscribe(function (params) {
            var parentTitle = params['parentTitle'];
            var tappedTitle = params['tappedTitle'];
            _this.hasBack = true;
            _this._currentExample = _this._exampleItemsService.getChildExampleItem(parentTitle, tappedTitle, _this._exampleItemsService.getAllExampleItems());
        });
    };
    ExamplesListDepth3Component.prototype.ngOnDestroy = function () {
        this._sub.unsubscribe();
    };
    Object.defineProperty(ExamplesListDepth3Component.prototype, "currentExample", {
        get: function () {
            return this._currentExample;
        },
        set: function (value) {
            this._currentExample = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ExamplesListDepth3Component.prototype, "hasBack", {
        get: function () {
            return this._hasBack;
        },
        set: function (value) {
            this._hasBack = value;
        },
        enumerable: true,
        configurable: true
    });
    ExamplesListDepth3Component.prototype.onNavigationItemTap = function (args) {
        var itemIndex = args.itemIndex;
        var tappedItem = this._currentExample.subItems[itemIndex];
        this._router.navigate(['/example', this._currentExample.title, tappedItem.title]);
    };
    ExamplesListDepth3Component.prototype.onNavigationButtonTap = function () {
        FrameModule.topmost().goBack();
    };
    ExamplesListDepth3Component = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "examples-depth-3",
            templateUrl: "examples-list.component.html",
            styleUrls: ["examples-list.component.css"]
        }), 
        __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, exampleItemService_service_1.ExampleItemService])
    ], ExamplesListDepth3Component);
    return ExamplesListDepth3Component;
}());
exports.ExamplesListDepth3Component = ExamplesListDepth3Component;
