var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var mock_exampleItems_1 = require("./mock-exampleItems");
var ExampleItemService = (function () {
    function ExampleItemService() {
    }
    ExampleItemService.prototype.getAllExampleItems = function () {
        return mock_exampleItems_1.EXAMPLEITEMS;
    };
    ExampleItemService.prototype.getParentExampleItem = function (index) {
        return mock_exampleItems_1.EXAMPLEITEMS[index];
    };
    ExampleItemService.prototype.getChildExampleItem = function (parentTitle, subItemTitle, exampleItems) {
        if (exampleItems) {
            for (var index = 0; index < exampleItems.length; index++) {
                var element = exampleItems[index];
                if (element.title === parentTitle) {
                    var parentExampleItem = element;
                    if (parentExampleItem && parentExampleItem.subItems.length >= 0) {
                        var childItem = parentExampleItem.subItems.filter(function (item) { return item.title === subItemTitle; })[0];
                        return childItem;
                    }
                }
                else {
                    if (element.subItems.length >= 0) {
                        var result = this.getChildExampleItem(parentTitle, subItemTitle, element.subItems);
                        if (result) {
                            return result;
                        }
                    }
                }
            }
        }
    };
    ExampleItemService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], ExampleItemService);
    return ExampleItemService;
}());
exports.ExampleItemService = ExampleItemService;
