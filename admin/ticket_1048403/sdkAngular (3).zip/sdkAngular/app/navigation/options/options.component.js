var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var observable_array_1 = require("data/observable-array");
var router_1 = require('@angular/router');
var frameModule = require("ui/frame");
var page_1 = require("ui/page");
var options_service_1 = require("../../navigation/options/options.service");
var OptionsComponent = (function () {
    function OptionsComponent(_page, _router, _optionsService) {
        this._page = _page;
        this._router = _router;
        this._optionsService = _optionsService;
        this._selectedIndex = -1;
        this._page.on("loaded", this.onLoaded, this);
        this._dataItems = new observable_array_1.ObservableArray();
    }
    OptionsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._sub = this._router
            .routerState
            .queryParams
            .subscribe(function (params) {
            _this._listView = _this._page.getViewById("optionsListView");
            var items = params['items'];
            _this._selectedIndex = +params['selectedIndex'];
            if (items) {
                var splitItems = items.toString().split(',');
                _this._dataItems = new observable_array_1.ObservableArray(splitItems);
                _this.tryUpdateListViewSelection();
            }
        });
    };
    OptionsComponent.prototype.ngOnDestroy = function () {
        this._sub.unsubscribe();
    };
    OptionsComponent.prototype.onLoaded = function () {
        this._listView = this._page.getViewById("optionsListView");
        this.tryUpdateListViewSelection();
    };
    OptionsComponent.prototype.tryUpdateListViewSelection = function () {
        if (this._selectedIndex >= 0 && this._listView) {
            this._listView.selectItemAt(this._selectedIndex);
        }
    };
    Object.defineProperty(OptionsComponent.prototype, "dataItems", {
        get: function () {
            return this._dataItems;
        },
        enumerable: true,
        configurable: true
    });
    OptionsComponent.prototype.onItemTap = function (args) {
        var selectedItems = this._listView.getSelectedItems();
        this._optionsService.paramValue = selectedItems[0];
        frameModule.topmost().goBack();
    };
    OptionsComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "options",
            templateUrl: "options.component.html",
            styleUrls: ["options.component.css"]
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [Object, router_1.Router, options_service_1.OptionsService])
    ], OptionsComponent);
    return OptionsComponent;
}());
exports.OptionsComponent = OptionsComponent;
