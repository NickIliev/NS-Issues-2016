var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var exampleItemService_service_1 = require("../exampleItemService.service");
var router_1 = require('@angular/router');
var frameModule = require("ui/frame");
var listview_getting_started_component_1 = require("../../listview/getting-started/listview-getting-started.component");
var listview_header_footer_component_1 = require("../../listview/header-footer/listview-header-footer.component");
var listview_item_reorder_component_1 = require("../../listview/item-reorder/listview-item-reorder.component");
var listview_item_selection_component_1 = require("../../listview/item-selection/listview-item-selection.component");
var listview_item_swipe_component_1 = require("../../listview/item-swipe/listview-item-swipe.component");
var listview_load_on_demand_component_1 = require("../../listview/load-on-demand/listview-load-on-demand.component");
var listview_pull_to_refresh_component_1 = require("../../listview/pull-to-refresh/listview-pull-to-refresh.component");
var getting_started_component_1 = require("../../sidedrawer/getting-started/getting-started.component");
var events_component_1 = require("../../sidedrawer/events/events.component");
var position_component_1 = require("../../sidedrawer/position/position.component");
var transitions_component_1 = require("../../sidedrawer/transitions/transitions.component");
var calendar_getting_started_component_1 = require("../../calendar/getting-started/calendar-getting-started.component");
var calendar_populating_with_data_component_1 = require("../../calendar/populating-with-data/calendar-populating-with-data.component");
var calendar_programatic_control_component_1 = require("../../calendar/programatic-control/calendar-programatic-control.component");
var calendar_view_modes_component_1 = require("../../calendar/view-modes/calendar-view-modes.component");
var calendar_selection_modes_component_1 = require("../../calendar/selection-modes/calendar-selection-modes.component");
var calendar_cell_styling_component_1 = require("../../calendar/cell-styling/calendar-cell-styling.component");
var calendar_events_view_modes_component_1 = require("../../calendar/events-view-modes/calendar-events-view-modes.component");
var calendar_transition_modes_component_1 = require("../../calendar/transition-modes/calendar-transition-modes.component");
var chart_series_area_component_1 = require("../../chart/series/area/chart-series-area.component");
var chart_series_stacked_area_component_1 = require("../../chart/series/area/chart-series-stacked-area.component");
var chart_series_bar_component_1 = require("../../chart/series/bar/chart-series-bar.component");
var chart_series_range_bar_component_1 = require("../../chart/series/bar/chart-series-range-bar.component");
var chart_series_stacked_bar_component_1 = require("../../chart/series/bar/chart-series-stacked-bar.component");
var chart_series_bubble_component_1 = require("../../chart/series/bubble/chart-series-bubble.component");
var chart_series_scatter_bubble_component_1 = require("../../chart/series/bubble/chart-series-scatter-bubble.component");
var chart_series_candlestick_component_1 = require("../../chart/series/financial/chart-series-candlestick.component");
var chart_series_ohlc_component_1 = require("../../chart/series/financial/chart-series-ohlc.component");
var chart_series_line_component_1 = require("../../chart/series/line/chart-series-line.component");
var chart_series_pie_component_1 = require("../../chart/series/pie/chart-series-pie.component");
var chart_series_scatter_component_1 = require("../../chart/series/scatter/chart-series-scatter.component");
var chart_series_spline_component_1 = require("../../chart/series/spline/chart-series-spline.component");
var ExampleComponent = (function () {
    function ExampleComponent(_router, _route, _exampleItemsService, _loader) {
        this._router = _router;
        this._route = _route;
        this._exampleItemsService = _exampleItemsService;
        this._loader = _loader;
    }
    ExampleComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._sub = this._route.params.subscribe(function (params) {
            var parentTitle = params['parentTitle'];
            var tappedTitle = params['tappedTitle'];
            _this._currentExample = _this._exampleItemsService.getChildExampleItem(parentTitle, tappedTitle, _this._exampleItemsService.getAllExampleItems());
        });
    };
    ExampleComponent.prototype.ngOnDestroy = function () {
        this._sub.unsubscribe();
    };
    ExampleComponent.prototype.ngAfterViewInit = function () {
        //Loads the current example component.
        switch (this.currentExample.path) {
            case "ListViewGettingStarted":
                this._loader.loadNextToLocation(listview_getting_started_component_1.ListViewGettingStartedComponent, this.exampleCompPlaceholder);
                break;
            case "ListViewHeaderFooter":
                this._loader.loadNextToLocation(listview_header_footer_component_1.ListViewHeaderFooterComponent, this.exampleCompPlaceholder);
                break;
            case "ListViewItemReorder":
                this._loader.loadNextToLocation(listview_item_reorder_component_1.ListViewItemReorderComponent, this.exampleCompPlaceholder);
                break;
            case "ListViewItemSelection":
                this._loader.loadNextToLocation(listview_item_selection_component_1.ListViewItemSelectionComponent, this.exampleCompPlaceholder);
                break;
            case "ListViewItemSwipe":
                this._loader.loadNextToLocation(listview_item_swipe_component_1.ListViewItemSwipeComponent, this.exampleCompPlaceholder);
                break;
            case "ListViewLoadOnDemand":
                this._loader.loadNextToLocation(listview_load_on_demand_component_1.ListViewLoadOnDemandComponent, this.exampleCompPlaceholder);
                break;
            case "ListViewPullToRefresh":
                this._loader.loadNextToLocation(listview_pull_to_refresh_component_1.ListViewPullToRefreshComponent, this.exampleCompPlaceholder);
                break;
            case "SideDrawerGettingStarted":
                this._loader.loadNextToLocation(getting_started_component_1.SideDrawerGettingStartedComponent, this.exampleCompPlaceholder);
                break;
            case "SideDrawerEvents":
                this._loader.loadNextToLocation(events_component_1.SideDrawerEventsComponent, this.exampleCompPlaceholder);
                break;
            case "SideDrawerPosition":
                this._loader.loadNextToLocation(position_component_1.SideDrawerPositionComponent, this.exampleCompPlaceholder);
                break;
            case "SideDrawerTransitions":
                this._loader.loadNextToLocation(transitions_component_1.SideDrawerTransitionsComponent, this.exampleCompPlaceholder);
                break;
            case "CalendarGettingStarted":
                this._loader.loadNextToLocation(calendar_getting_started_component_1.CalendarGettingStartedComponent, this.exampleCompPlaceholder);
                break;
            case "CalendarPopulatingWithData":
                this._loader.loadNextToLocation(calendar_populating_with_data_component_1.CalendarPopulatingWithDataComponent, this.exampleCompPlaceholder);
                break;
            case "CalendarProgramaticControl":
                this._loader.loadNextToLocation(calendar_programatic_control_component_1.CalendarProgramaticControlComponent, this.exampleCompPlaceholder);
                break;
            case "CalendarViewModes":
                this._loader.loadNextToLocation(calendar_view_modes_component_1.CalendarViewModesComponent, this.exampleCompPlaceholder);
                break;
            case "CalendarSelectionModes":
                this._loader.loadNextToLocation(calendar_selection_modes_component_1.CalendarSelectionModesComponent, this.exampleCompPlaceholder);
                break;
            case "CalendarCellStyling":
                this._loader.loadNextToLocation(calendar_cell_styling_component_1.CalendarCellStylingComponent, this.exampleCompPlaceholder);
                break;
            case "CalendarEventsViewModes":
                this._loader.loadNextToLocation(calendar_events_view_modes_component_1.CalendarEventsViewModesComponent, this.exampleCompPlaceholder);
                break;
            case "CalendarTransitionModes":
                this._loader.loadNextToLocation(calendar_transition_modes_component_1.CalendarTransitionModesComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesArea":
                this._loader.loadNextToLocation(chart_series_area_component_1.ChartSeriesAreaComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesStackedArea":
                this._loader.loadNextToLocation(chart_series_stacked_area_component_1.ChartSeriesStackedAreaComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesBar":
                this._loader.loadNextToLocation(chart_series_bar_component_1.ChartSeriesBarComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesRangeBar":
                this._loader.loadNextToLocation(chart_series_range_bar_component_1.ChartSeriesRangeBarComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesStackedBar":
                this._loader.loadNextToLocation(chart_series_stacked_bar_component_1.ChartSeriesStackedBarComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesBubble":
                this._loader.loadNextToLocation(chart_series_bubble_component_1.ChartSeriesBubbleComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesScatterBubble":
                this._loader.loadNextToLocation(chart_series_scatter_bubble_component_1.ChartSeriesScatterBubbleComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesCandlestick":
                this._loader.loadNextToLocation(chart_series_candlestick_component_1.ChartSeriesCandlestickComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesOhlc":
                this._loader.loadNextToLocation(chart_series_ohlc_component_1.ChartSeriesOhlcComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesLine":
                this._loader.loadNextToLocation(chart_series_line_component_1.ChartSeriesLineComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesPie":
                this._loader.loadNextToLocation(chart_series_pie_component_1.ChartSeriesPieComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesScatter":
                this._loader.loadNextToLocation(chart_series_scatter_component_1.ChartSeriesScatterComponent, this.exampleCompPlaceholder);
                break;
            case "ChartSeriesSpline":
                this._loader.loadNextToLocation(chart_series_spline_component_1.ChartSeriesSplineComponent, this.exampleCompPlaceholder);
                break;
            default:
                return null;
        }
    };
    Object.defineProperty(ExampleComponent.prototype, "currentExample", {
        get: function () {
            return this._currentExample;
        },
        set: function (value) {
            this._currentExample = value;
        },
        enumerable: true,
        configurable: true
    });
    ExampleComponent.prototype.onNavigationButtonTap = function () {
        frameModule.topmost().goBack();
    };
    __decorate([
        core_1.ViewChild('exampleCompPlaceholder', { read: core_1.ViewContainerRef }), 
        __metadata('design:type', core_1.ViewContainerRef)
    ], ExampleComponent.prototype, "exampleCompPlaceholder", void 0);
    ExampleComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "example",
            templateUrl: "example.component.html"
        }), 
        __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, exampleItemService_service_1.ExampleItemService, core_1.DynamicComponentLoader])
    ], ExampleComponent);
    return ExampleComponent;
}());
exports.ExampleComponent = ExampleComponent;
