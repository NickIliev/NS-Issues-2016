var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var calendar_events_service_1 = require("../calendar-events.service");
// >> angular-calenda-populating-with-data
var CalendarPopulatingWithDataComponent = (function () {
    function CalendarPopulatingWithDataComponent(_calendarService) {
        this._calendarService = _calendarService;
    }
    Object.defineProperty(CalendarPopulatingWithDataComponent.prototype, "eventSource", {
        get: function () {
            return this._events;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CalendarPopulatingWithDataComponent.prototype, "myItems", {
        get: function () {
            return this._listItems;
        },
        set: function (value) {
            this._listItems = value;
        },
        enumerable: true,
        configurable: true
    });
    CalendarPopulatingWithDataComponent.prototype.ngOnInit = function () {
        this._events = this._calendarService.getCalendarEvents();
    };
    CalendarPopulatingWithDataComponent.prototype.onDateSelected = function (args) {
        var calendar = args.object;
        var date = args.date;
        var events = calendar.getEventsForDate(date);
        this.myItems = events;
    };
    CalendarPopulatingWithDataComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "calendar-populating-with-data",
            templateUrl: "calendar-populating-with-data.component.html",
            styleUrls: ["calendar-populating-with-data.component.css"],
            providers: [calendar_events_service_1.CalendarEventsService]
        }), 
        __metadata('design:paramtypes', [calendar_events_service_1.CalendarEventsService])
    ], CalendarPopulatingWithDataComponent);
    return CalendarPopulatingWithDataComponent;
}());
exports.CalendarPopulatingWithDataComponent = CalendarPopulatingWithDataComponent;
// << angular-calenda-populating-with-data 
