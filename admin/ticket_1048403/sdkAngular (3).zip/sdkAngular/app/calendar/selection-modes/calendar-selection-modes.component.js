var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var options_example_base_1 = require("../../options-example-base");
var core_1 = require("@angular/core");
var router_1 = require('@angular/router');
var page_1 = require("ui/page");
var calendarModule = require("nativescript-telerik-ui-pro/calendar");
var applicationModule = require("application");
var options_service_1 = require("../../navigation/options/options.service");
var CalendarSelectionModesComponent = (function (_super) {
    __extends(CalendarSelectionModesComponent, _super);
    function CalendarSelectionModesComponent(_page, _router, _optionsService) {
        _super.call(this);
        this._page = _page;
        this._router = _router;
        this._optionsService = _optionsService;
        if (applicationModule.ios) {
            this._page.on("navigatingTo", this.onNavigatingTo, this);
            this._optionsParamName = "selectionMode";
            this._optionsService.paramName = this._optionsParamName;
            this.router = _router;
            this.navigationParameters = { selectedIndex: 0, paramName: this._optionsParamName, items: ["None", "Single", "Multiple", "Range"] };
        }
        this._selectionMode = calendarModule.CalendarSelectionMode.None;
    }
    Object.defineProperty(CalendarSelectionModesComponent.prototype, "selectionMode", {
        get: function () {
            return this._selectionMode;
        },
        enumerable: true,
        configurable: true
    });
    CalendarSelectionModesComponent.prototype.ngOnInit = function () {
        this._calendar = this._page.getViewById("calendar");
    };
    CalendarSelectionModesComponent.prototype.onNoneTap = function () {
        this._selectionMode = calendarModule.CalendarSelectionMode.None;
        this._calendar.reload();
    };
    CalendarSelectionModesComponent.prototype.onSingleTap = function () {
        this._selectionMode = calendarModule.CalendarSelectionMode.Single;
        this._calendar.reload();
    };
    CalendarSelectionModesComponent.prototype.onMultipleTap = function () {
        this._selectionMode = calendarModule.CalendarSelectionMode.Multiple;
        this._calendar.reload();
    };
    CalendarSelectionModesComponent.prototype.onRangeTap = function () {
        this._selectionMode = calendarModule.CalendarSelectionMode.Range;
        this._calendar.reload();
    };
    CalendarSelectionModesComponent.prototype.onNavigatingTo = function (args) {
        if (args.isBackNavigation) {
            if (this._optionsService.paramName === this._optionsParamName) {
                switch (this._optionsService.paramValue) {
                    case "None":
                        this.onNoneTap();
                        this.navigationParameters.selectedIndex = 0;
                        break;
                    case "Single":
                        this.onSingleTap();
                        this.navigationParameters.selectedIndex = 1;
                        break;
                    case "Multiple":
                        this.onMultipleTap();
                        this.navigationParameters.selectedIndex = 2;
                        break;
                    case "Range":
                        this.onRangeTap();
                        this.navigationParameters.selectedIndex = 3;
                        break;
                    default:
                        break;
                }
            }
        }
    };
    CalendarSelectionModesComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "calendar-selection-modes",
            templateUrl: "calendar-selection-modes.component.html"
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, router_1.Router, options_service_1.OptionsService])
    ], CalendarSelectionModesComponent);
    return CalendarSelectionModesComponent;
}(options_example_base_1.OptionsExampleBase));
exports.CalendarSelectionModesComponent = CalendarSelectionModesComponent;
// << angular-calendar-selection-modes 
