var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var options_example_base_1 = require("../../options-example-base");
var core_1 = require("@angular/core");
var router_1 = require('@angular/router');
var page_1 = require("ui/page");
var options_service_1 = require("../../navigation/options/options.service");
var calendar_1 = require("nativescript-telerik-ui-pro/calendar");
var applicationModule = require("application");
var CalendarViewModesComponent = (function (_super) {
    __extends(CalendarViewModesComponent, _super);
    function CalendarViewModesComponent(_page, _optionsService, _router) {
        _super.call(this);
        this._page = _page;
        this._optionsService = _optionsService;
        this._router = _router;
        if (applicationModule.ios) {
            this._page.on("navigatingTo", this.onNavigatingTo, this);
            this._optionsParamName = "eventsViewMode";
            this._optionsService.paramName = this._optionsParamName;
            this.router = _router;
            this.navigationParameters = { selectedIndex: 1, paramName: this._optionsParamName, items: ["Week", "Month", "Month names", "Year"] };
        }
        this._viewMode = calendar_1.CalendarViewMode.Month;
    }
    Object.defineProperty(CalendarViewModesComponent.prototype, "viewMode", {
        get: function () {
            return this._viewMode;
        },
        enumerable: true,
        configurable: true
    });
    CalendarViewModesComponent.prototype.ngOnInit = function () {
        this._calendar = this._page.getViewById("calendar");
    };
    CalendarViewModesComponent.prototype.onWeekTap = function () {
        this._viewMode = calendar_1.CalendarViewMode.Week;
    };
    CalendarViewModesComponent.prototype.onMonthTap = function () {
        this._viewMode = calendar_1.CalendarViewMode.Month;
    };
    CalendarViewModesComponent.prototype.onMonthNamesTap = function () {
        this._viewMode = calendar_1.CalendarViewMode.MonthNames;
    };
    CalendarViewModesComponent.prototype.onYearTap = function () {
        this._viewMode = calendar_1.CalendarViewMode.Year;
    };
    CalendarViewModesComponent.prototype.onNavigatingTo = function (args) {
        if (args.isBackNavigation) {
            if (this._optionsService.paramName === this._optionsParamName) {
                switch (this._optionsService.paramValue) {
                    case "Week":
                        this.onWeekTap();
                        this.navigationParameters.selectedIndex = 0;
                        break;
                    case "Month":
                        this.onMonthTap();
                        this.navigationParameters.selectedIndex = 1;
                        break;
                    case "Month names":
                        this.onMonthNamesTap();
                        this.navigationParameters.selectedIndex = 2;
                        break;
                    case "Year":
                        this.onYearTap();
                        this.navigationParameters.selectedIndex = 3;
                        break;
                    default:
                        break;
                }
            }
        }
    };
    CalendarViewModesComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "calendar-view-modes",
            templateUrl: "calendar-view-modes.component.html"
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, options_service_1.OptionsService, router_1.Router])
    ], CalendarViewModesComponent);
    return CalendarViewModesComponent;
}(options_example_base_1.OptionsExampleBase));
exports.CalendarViewModesComponent = CalendarViewModesComponent;
