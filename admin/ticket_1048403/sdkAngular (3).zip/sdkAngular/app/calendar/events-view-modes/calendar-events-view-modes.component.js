var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var options_example_base_1 = require("../../options-example-base");
var core_1 = require("@angular/core");
var router_1 = require('@angular/router');
var calendar_events_service_1 = require("../calendar-events.service");
var options_service_1 = require("../../navigation/options/options.service");
var calendarModule = require("nativescript-telerik-ui-pro/calendar");
var page_1 = require("ui/page");
var applicationModule = require("application");
var CalendarEventsViewModesComponent = (function (_super) {
    __extends(CalendarEventsViewModesComponent, _super);
    function CalendarEventsViewModesComponent(_page, _calendarService, _optionsService, _router) {
        _super.call(this);
        this._page = _page;
        this._calendarService = _calendarService;
        this._optionsService = _optionsService;
        this._router = _router;
        if (applicationModule.ios) {
            this._page.on("navigatingTo", this.onNavigatingTo, this);
            this._optionsParamName = "eventsViewMode";
            this._optionsService.paramName = this._optionsParamName;
            this.router = _router;
            this.navigationParameters = { selectedIndex: 0, paramName: this._optionsParamName, items: ["None", "Inline", "Popover (iPad only)"] };
        }
        this._eventsViewMode = calendarModule.CalendarEventsViewMode.None;
    }
    Object.defineProperty(CalendarEventsViewModesComponent.prototype, "eventSource", {
        get: function () {
            return this._events;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CalendarEventsViewModesComponent.prototype, "eventsViewMode", {
        get: function () {
            return this._eventsViewMode;
        },
        enumerable: true,
        configurable: true
    });
    CalendarEventsViewModesComponent.prototype.ngOnInit = function () {
        this._events = this._calendarService.getCalendarEvents();
        this._calendar = this._page.getViewById("calendar");
    };
    CalendarEventsViewModesComponent.prototype.onNoneTap = function () {
        this._eventsViewMode = calendarModule.CalendarEventsViewMode.None;
    };
    CalendarEventsViewModesComponent.prototype.onInlineTap = function () {
        this._eventsViewMode = calendarModule.CalendarEventsViewMode.Inline;
    };
    CalendarEventsViewModesComponent.prototype.onPopoverTap = function () {
        this._eventsViewMode = calendarModule.CalendarEventsViewMode.Popover;
    };
    CalendarEventsViewModesComponent.prototype.onNavigatingTo = function (args) {
        if (args.isBackNavigation) {
            if (this._optionsService.paramName === this._optionsParamName) {
                switch (this._optionsService.paramValue) {
                    case "None":
                        this.onNoneTap();
                        this.navigationParameters.selectedIndex = 0;
                        break;
                    case "Inline":
                        this.onInlineTap();
                        this.navigationParameters.selectedIndex = 1;
                        break;
                    case "Popover":
                        if (UIDevice.currentDevice().userInterfaceIdiom === UIUserInterfaceIdiomPad) {
                            this.onPopoverTap();
                            this.navigationParameters.selectedIndex = 2;
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    };
    CalendarEventsViewModesComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "calendar-events-view-modes",
            templateUrl: "calendar-events-view-modes.component.html",
            providers: [calendar_events_service_1.CalendarEventsService]
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, calendar_events_service_1.CalendarEventsService, options_service_1.OptionsService, router_1.Router])
    ], CalendarEventsViewModesComponent);
    return CalendarEventsViewModesComponent;
}(options_example_base_1.OptionsExampleBase));
exports.CalendarEventsViewModesComponent = CalendarEventsViewModesComponent;
