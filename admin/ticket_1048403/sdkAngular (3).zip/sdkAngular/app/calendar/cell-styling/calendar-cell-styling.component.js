var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var page_1 = require("ui/page");
var calendarModule = require("nativescript-telerik-ui-pro/calendar");
var calendar_styles_service_1 = require("../calendar-styles.service");
var applicationModule = require("application");
var options_service_1 = require("../../navigation/options/options.service");
var router_1 = require('@angular/router');
var options_example_base_1 = require("../../options-example-base");
var CalendarCellStylingComponent = (function (_super) {
    __extends(CalendarCellStylingComponent, _super);
    function CalendarCellStylingComponent(_page, _calendarService, _optionsService, _router) {
        _super.call(this);
        this._page = _page;
        this._calendarService = _calendarService;
        this._optionsService = _optionsService;
        this._router = _router;
        if (applicationModule.ios) {
            this._page.on("navigatingTo", this.onNavigatingTo, this);
            this._optionsParamName = "eventsViewMode";
            this._optionsService.paramName = this._optionsParamName;
            this.router = _router;
            this.navigationParameters = { selectedIndex: 1, paramName: this._optionsParamName, items: ["Week", "Month", "Month names", "Year"] };
        }
        this._viewMode = calendarModule.CalendarViewMode.Month;
    }
    CalendarCellStylingComponent.prototype.ngOnInit = function () {
        this._calendar = this._page.getViewById("calendar");
        this._monthViewStyle = this._calendarService.getMonthViewStyle();
        this._monthNamesViewStyle = this._calendarService.getMonthNamesViewStyle();
        this._weekViewStyle = this._calendarService.getWeekViewStyle();
        this._yearViewStyle = this._calendarService.getYearViewStyle();
    };
    Object.defineProperty(CalendarCellStylingComponent.prototype, "viewMode", {
        get: function () {
            return this._viewMode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CalendarCellStylingComponent.prototype, "monthViewStyle", {
        get: function () {
            return this._monthViewStyle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CalendarCellStylingComponent.prototype, "monthNamesViewStyle", {
        get: function () {
            return this._monthNamesViewStyle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CalendarCellStylingComponent.prototype, "yearViewStyle", {
        get: function () {
            return this._yearViewStyle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CalendarCellStylingComponent.prototype, "weekViewStyle", {
        get: function () {
            return this._weekViewStyle;
        },
        enumerable: true,
        configurable: true
    });
    CalendarCellStylingComponent.prototype.onYearTap = function () {
        this._viewMode = calendarModule.CalendarViewMode.Year;
    };
    CalendarCellStylingComponent.prototype.onMonthNamesTap = function () {
        this._viewMode = calendarModule.CalendarViewMode.MonthNames;
    };
    CalendarCellStylingComponent.prototype.onMonthTap = function () {
        this._viewMode = calendarModule.CalendarViewMode.Month;
    };
    CalendarCellStylingComponent.prototype.onWeekTap = function () {
        this._viewMode = calendarModule.CalendarViewMode.Week;
    };
    CalendarCellStylingComponent.prototype.onNavigatingTo = function (args) {
        if (args.isBackNavigation) {
            if (this._optionsService.paramName === this._optionsParamName) {
                switch (this._optionsService.paramValue) {
                    case "Week":
                        this.onWeekTap();
                        this.navigationParameters.selectedIndex = 0;
                        break;
                    case "Month":
                        this.onMonthTap();
                        this.navigationParameters.selectedIndex = 1;
                        break;
                    case "Month names":
                        this.onMonthNamesTap();
                        this.navigationParameters.selectedIndex = 2;
                        break;
                    case "Year":
                        this.onYearTap();
                        this.navigationParameters.selectedIndex = 3;
                        break;
                    default:
                        break;
                }
            }
        }
    };
    CalendarCellStylingComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "calendar-cell-styling",
            templateUrl: "calendar-cell-styling.component.html",
            providers: [calendar_styles_service_1.CalendarStylesService]
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, calendar_styles_service_1.CalendarStylesService, options_service_1.OptionsService, router_1.Router])
    ], CalendarCellStylingComponent);
    return CalendarCellStylingComponent;
}(options_example_base_1.OptionsExampleBase));
exports.CalendarCellStylingComponent = CalendarCellStylingComponent;
