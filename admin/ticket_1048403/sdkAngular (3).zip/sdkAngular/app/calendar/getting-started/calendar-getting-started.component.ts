import {Component} from "@angular/core";

@Component({
    moduleId: module.id,
    selector: "calendar-getting-started",
    templateUrl: "calendar-getting-started.component.html"
})
export class CalendarGettingStartedComponent {
    constructor() {}
}