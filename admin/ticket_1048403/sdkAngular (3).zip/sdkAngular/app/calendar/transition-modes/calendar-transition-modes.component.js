var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var page_1 = require("ui/page");
var calendarModule = require("nativescript-telerik-ui-pro/calendar");
var options_service_1 = require("../../navigation/options/options.service");
var applicationModule = require("application");
var router_1 = require('@angular/router');
var options_example_base_1 = require("../../options-example-base");
var CalendarTransitionModesComponent = (function (_super) {
    __extends(CalendarTransitionModesComponent, _super);
    function CalendarTransitionModesComponent(_page, _optionsService, _router) {
        _super.call(this);
        this._page = _page;
        this._optionsService = _optionsService;
        this._router = _router;
        if (applicationModule.ios) {
            this._page.on("navigatingTo", this.onNavigatingTo, this);
            this._optionsParamName = "transitionMode";
            this._optionsService.paramName = this._optionsParamName;
            this.router = _router;
            this.navigationParameters = { selectedIndex: 0, paramName: this._optionsParamName,
                items: ["None", "Slide", "Stack", "Flip", "Fold", "Float", "Rotate"] };
        }
        this._transitionMode = calendarModule.CalendarTransitionMode.None;
    }
    Object.defineProperty(CalendarTransitionModesComponent.prototype, "transitionMode", {
        get: function () {
            return this._transitionMode;
        },
        enumerable: true,
        configurable: true
    });
    CalendarTransitionModesComponent.prototype.ngOnInit = function () {
        this._calendar = this._page.getViewById("calendar");
    };
    // common
    CalendarTransitionModesComponent.prototype.onNoneTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.None;
    };
    CalendarTransitionModesComponent.prototype.onSlideTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Slide;
    };
    CalendarTransitionModesComponent.prototype.onStackTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Stack;
    };
    // android
    CalendarTransitionModesComponent.prototype.onPlainTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Plain;
    };
    CalendarTransitionModesComponent.prototype.onFreeTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Free;
    };
    CalendarTransitionModesComponent.prototype.onComboTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Combo;
    };
    CalendarTransitionModesComponent.prototype.onOverlapTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Overlap;
    };
    //ios
    CalendarTransitionModesComponent.prototype.onFlipTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Flip;
    };
    CalendarTransitionModesComponent.prototype.onFoldTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Fold;
    };
    CalendarTransitionModesComponent.prototype.onFloatTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Float;
    };
    CalendarTransitionModesComponent.prototype.onRotateTap = function () {
        this._transitionMode = calendarModule.CalendarTransitionMode.Rotate;
    };
    CalendarTransitionModesComponent.prototype.onNavigatingTo = function (args) {
        if (args.isBackNavigation) {
            if (this._optionsService.paramName === this._optionsParamName) {
                switch (this._optionsService.paramValue) {
                    case "None":
                        this.onNoneTap();
                        this.navigationParameters.selectedIndex = 0;
                        break;
                    case "Slide":
                        this.onSlideTap();
                        this.navigationParameters.selectedIndex = 1;
                        break;
                    case "Stack":
                        this.onStackTap();
                        this.navigationParameters.selectedIndex = 2;
                        break;
                    case "Flip":
                        this.onFlipTap();
                        this.navigationParameters.selectedIndex = 3;
                        break;
                    case "Fold":
                        this.onFoldTap();
                        this.navigationParameters.selectedIndex = 4;
                        break;
                    case "Float":
                        this.onFloatTap();
                        this.navigationParameters.selectedIndex = 5;
                        break;
                    case "Rotate":
                        this.onRotateTap();
                        this.navigationParameters.selectedIndex = 6;
                        break;
                    default:
                        break;
                }
            }
        }
    };
    CalendarTransitionModesComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "calendar-transition-modes",
            templateUrl: "calendar-transition-modes.component.html"
        }),
        __param(0, core_1.Inject(page_1.Page)), 
        __metadata('design:paramtypes', [page_1.Page, options_service_1.OptionsService, router_1.Router])
    ], CalendarTransitionModesComponent);
    return CalendarTransitionModesComponent;
}(options_example_base_1.OptionsExampleBase));
exports.CalendarTransitionModesComponent = CalendarTransitionModesComponent;
