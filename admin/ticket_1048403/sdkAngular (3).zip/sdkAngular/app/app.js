var elementRegistryModule = require('nativescript-angular/element-registry');
// >> using-global-directives
var application_1 = require("nativescript-angular/application");
var angular_1 = require("nativescript-telerik-ui-pro/sidedrawer/angular");
var angular_2 = require('nativescript-telerik-ui-pro/listview/angular');
var angular_3 = require('nativescript-telerik-ui-pro/calendar/angular');
var angular_4 = require('nativescript-telerik-ui-pro/chart/angular');
var app_component_1 = require("./navigation/app.component");
var app_routes_1 = require("./navigation/app.routes");
// >> (hide)
var fresco_1 = require("fresco/fresco");
var applicationModule = require("application");
var options_service_1 = require("./navigation/options/options.service");
var exampleItemService_service_1 = require("./navigation/exampleItemService.service");
var router_1 = require("nativescript-angular/router");
var router_2 = require('@angular/router');
if (applicationModule.android) {
    applicationModule.onLaunch = function (intent) {
        com.facebook.drawee.backends.pipeline.Fresco.initialize(applicationModule.android.context);
    };
}
elementRegistryModule.registerElement("FrescoDrawee", function () { return fresco_1.FrescoDrawee; });
// << (hide)
application_1.nativeScriptBootstrap(app_component_1.AppComponent, [angular_2.LISTVIEW_PROVIDERS, angular_1.SIDEDRAWER_PROVIDERS, angular_3.CALENDAR_PROVIDERS, angular_4.CHART_PROVIDERS,
    app_routes_1.AppPageRouterOutletRouterProviders, options_service_1.OptionsService, exampleItemService_service_1.ExampleItemService, router_1.NS_ROUTER_PROVIDERS, router_2.RouterOutletMap], { startPageActionBarHidden: false });
// << using-global-directives 
