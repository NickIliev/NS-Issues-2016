var model = {
    FindPHRLocations: [
        //{ DisplayValue: "Search by...", Value: "Name" },
        { DisplayValue: "Select a UH Location", Value: "", Hint: "Select a UH Location" },
        { DisplayValue: "UH Elyria", Value: "UH Elyria", Hint: "UH Elyria" },
        { DisplayValue: "UH Parma", Value: "UH Parma", Hint: "UH Parma" },
        { DisplayValue: "UH Portage", Value: "UH Portage", Hint: "UH Portage" },
        { DisplayValue: "UH St. John", Value: "UH St. John", Hint: "UH St. John" },
        { DisplayValue: "UH Samaritan", Value: "UH Samaritan", Hint: "UH Samaritan" },
        { DisplayValue: "All Other UH Locations", Value: "All Other UH Locations", Hint: "All Other UH Locations" }
    ]
}

module.exports = model;