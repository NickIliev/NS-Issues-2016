"use strict";
var observable_1 = require("data/observable");
var frame_1 = require('ui/frame');
var viewModel = (function (_super) {
    __extends(viewModel, _super);
    function viewModel(page) {
        _super.call(this);
        this.testTap = function () {
            frame_1.topmost().navigate({ moduleName: "feenoteedit/feenoteedit" });
        };
        this.page = page;
    }
    return viewModel;
}(observable_1.Observable));
exports.viewModel = viewModel;
var thisViewModel;
function pageLoaded(args) {
    var page = args.object;
    if (!thisViewModel) {
        thisViewModel = new viewModel(page);
        page.bindingContext = thisViewModel;
    }
}
exports.pageLoaded = pageLoaded;
;
//# sourceMappingURL=home.js.map