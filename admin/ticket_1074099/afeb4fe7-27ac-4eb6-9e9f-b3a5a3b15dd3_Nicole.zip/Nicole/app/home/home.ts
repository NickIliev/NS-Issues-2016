import {Observable} from "data/observable";
import {ObservableArray} from "data/observable-array";
import {topmost} from 'ui/frame';
import {Page} from 'ui/page';

export class viewModel extends Observable{
    page : Page;
       
    constructor(page) {
        super();
        this.page = page;
   }
   
    public testTap = function()  {
      topmost().navigate({moduleName : "feenoteedit/feenoteedit"});
    };

}

var thisViewModel: viewModel;
export function pageLoaded(args) {
  var page = <Page>args.object;
  if(!thisViewModel) {
    thisViewModel = new viewModel(page);
    page.bindingContext = thisViewModel;
  }
};

