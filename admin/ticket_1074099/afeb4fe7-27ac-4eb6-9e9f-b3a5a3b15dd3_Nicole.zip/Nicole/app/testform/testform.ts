import * as df from "nativescript-telerik-ui-pro/dataform";

import { Observable } from "data/observable";
import { topmost } from 'ui/frame';
import { Page } from 'ui/page';


export class FilenoteRow1 {
    description: string = 'test';
    date = new Date();
    amount: number = 1000.5;
}

export class FilenoteData {

    row: FilenoteRow1;

    constructor(data: FilenoteRow1) {
        this.row = data;
    }
}

export class FilenoteRow2 extends Observable {
    description: string = 'test';
    date = new Date();
    amount: number = 1000.5;
}

export class viewModel extends Observable {
    private page: Page = null;

    public filenoteRow1 = new FilenoteRow1();
    public filenoteRow2 = new FilenoteRow2();

    constructor(page) {
        super();
        var me = this;
        this.page = page;
        var dataForm = <df.RadDataForm>me.page.getViewById("dataForm")
        dataForm.source = me.filenoteRow1;
    }

    onUpdateTap(){
        var me = this;
        var dataForm = <df.RadDataForm>me.page.getViewById("dataForm")
        var data = new FilenoteRow1();
        data.description = "Eeee";
        dataForm.source = data;
    }

}

export function pageLoaded(args) {
    var page = <Page>args.object;
    page.bindingContext = new viewModel(page);
};