"use strict";
var observable_1 = require("data/observable");
var FilenoteRow1 = (function () {
    function FilenoteRow1() {
        this.description = 'test';
        this.date = new Date();
        this.amount = 1000.5;
    }
    return FilenoteRow1;
}());
exports.FilenoteRow1 = FilenoteRow1;
var FilenoteData = (function () {
    function FilenoteData(data) {
        this.row = data;
    }
    return FilenoteData;
}());
exports.FilenoteData = FilenoteData;
var FilenoteRow2 = (function (_super) {
    __extends(FilenoteRow2, _super);
    function FilenoteRow2() {
        _super.apply(this, arguments);
        this.description = 'test';
        this.date = new Date();
        this.amount = 1000.5;
    }
    return FilenoteRow2;
}(observable_1.Observable));
exports.FilenoteRow2 = FilenoteRow2;
var viewModel = (function (_super) {
    __extends(viewModel, _super);
    function viewModel(page) {
        _super.call(this);
        this.page = null;
        this.filenoteRow1 = new FilenoteRow1();
        this.filenoteRow2 = new FilenoteRow2();
        var me = this;
        this.page = page;
        var dataForm = me.page.getViewById("dataForm");
        dataForm.source = me.filenoteRow1;
    }
    viewModel.prototype.onUpdateTap = function () {
        var me = this;
        var dataForm = me.page.getViewById("dataForm");
        var data = new FilenoteRow1();
        data.description = "Eeee";
        dataForm.source = data;
    };
    return viewModel;
}(observable_1.Observable));
exports.viewModel = viewModel;
function pageLoaded(args) {
    var page = args.object;
    page.bindingContext = new viewModel(page);
}
exports.pageLoaded = pageLoaded;
;
//# sourceMappingURL=testform.js.map