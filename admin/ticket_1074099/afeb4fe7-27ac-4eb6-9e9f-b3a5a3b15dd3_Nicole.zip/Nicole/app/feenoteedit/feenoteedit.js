"use strict";
var observable_1 = require("data/observable");
var viewModel = (function (_super) {
    __extends(viewModel, _super);
    function viewModel(page) {
        _super.call(this);
        this.page = null;
        this.page = page;
        var me = this;
        me.set("myData", "some text");
        me.set("isItemVisible", false);
    }
    viewModel.prototype.buttonTap = function () {
        var me = this;
        me.set("myData", "some longer text");
        me.set("isItemVisible", true);
    };
    return viewModel;
}(observable_1.Observable));
exports.viewModel = viewModel;
function pageLoaded(args) {
    var page = args.object;
    page.bindingContext = new viewModel(page);
}
exports.pageLoaded = pageLoaded;
;
//# sourceMappingURL=feenoteedit.js.map