import { Observable } from "data/observable";
import { Page } from 'ui/page';

export class viewModel extends Observable {
    private page: Page = null;

    constructor(page) {
        super();
        this.page = page;
        var me = this;
        me.set("myData", "some text");
        me.set("isItemVisible", false);
    }
 
    public buttonTap() {
        var me = this;
        me.set("myData", "some longer text");
        me.set("isItemVisible", true);
    }

}

export function pageLoaded(args) {
    var page = <Page>args.object;
    page.bindingContext = new viewModel(page);
};