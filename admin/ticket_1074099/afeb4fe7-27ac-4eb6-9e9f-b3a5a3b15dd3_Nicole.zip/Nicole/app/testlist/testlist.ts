import {Observable} from "data/observable";
import {ObservableArray} from "data/observable-array";
import {Page} from 'ui/page';
import * as listViewModule from 'nativescript-telerik-ui-pro/listview';


export class viewModel extends Observable{
    page : Page;
    public items = new ObservableArray<any>();

    public data = [
             {description: "ddd"},
             {description: "eee"},
             {description: "fff"},
          ];
  
    constructor(page) {
        super();
        this.page = page;
        this.replaceArray(this.items,this.data);
   }


public pullToRefreshInitiated(args: listViewModule.ListViewEventData) {
        var me = this;
        var listView = args.object;
        listView.notifyPullToRefreshFinished();
  }
  

public replaceArray(array: ObservableArray<any>, withArray: any) {
        array.splice(0);
        for (var index = 0; index < withArray.length; index++) {
                array.push(withArray[index]);   
        }
  }



}

export function pageLoaded(args) {
    var page = <Page>args.object;
    page.bindingContext = new viewModel(page);
};