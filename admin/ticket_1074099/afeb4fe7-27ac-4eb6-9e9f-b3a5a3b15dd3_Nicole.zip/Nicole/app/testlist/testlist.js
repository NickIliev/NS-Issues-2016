"use strict";
var observable_1 = require("data/observable");
var observable_array_1 = require("data/observable-array");
var viewModel = (function (_super) {
    __extends(viewModel, _super);
    function viewModel(page) {
        _super.call(this);
        this.items = new observable_array_1.ObservableArray();
        this.data = [
            { description: "ddd" },
            { description: "eee" },
            { description: "fff" },
        ];
        this.page = page;
        this.replaceArray(this.items, this.data);
    }
    viewModel.prototype.pullToRefreshInitiated = function (args) {
        var me = this;
        var listView = args.object;
        listView.notifyPullToRefreshFinished();
    };
    viewModel.prototype.replaceArray = function (array, withArray) {
        array.splice(0);
        for (var index = 0; index < withArray.length; index++) {
            array.push(withArray[index]);
        }
    };
    return viewModel;
}(observable_1.Observable));
exports.viewModel = viewModel;
function pageLoaded(args) {
    var page = args.object;
    page.bindingContext = new viewModel(page);
}
exports.pageLoaded = pageLoaded;
;
//# sourceMappingURL=testlist.js.map