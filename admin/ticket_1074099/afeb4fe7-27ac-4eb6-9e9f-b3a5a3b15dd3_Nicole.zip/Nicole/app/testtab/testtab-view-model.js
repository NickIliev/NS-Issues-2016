"use strict";
var observable_array_1 = require("data/observable-array");
var observable_1 = require("data/observable");
var viewModel = (function (_super) {
    __extends(viewModel, _super);
    function viewModel() {
        _super.call(this);
    }
    viewModel.prototype.loadData = function () {
        //Tab 1
        var data1 = [
            { description: "aaa" },
            { description: "bbb" },
            { description: "ccc" },
        ];
        var arr1 = new observable_array_1.ObservableArray();
        data1.forEach(function (entry) {
            arr1.push(entry);
        });
        this.set("rows1", arr1);
        //Tab 2
        var data2 = [
            { description: "ddd" },
            { description: "eee" },
            { description: "fff" },
        ];
        var arr2 = new observable_array_1.ObservableArray();
        data2.forEach(function (entry) {
            arr2.push(entry);
        });
        this.set("rows2", arr2);
    };
    return viewModel;
}(observable_1.Observable));
exports.viewModel = viewModel;
//# sourceMappingURL=testtab-view-model.js.map