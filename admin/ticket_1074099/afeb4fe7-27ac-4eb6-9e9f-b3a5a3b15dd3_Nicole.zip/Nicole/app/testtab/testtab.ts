import * as vmModule from "./testtab-view-model";
import {Page} from 'ui/page';

var vm = new vmModule.viewModel();

export function onNavigatedTo(args) {
    var page = <Page>args.object;
    page.bindingContext = vm;
    vm.loadData();
};