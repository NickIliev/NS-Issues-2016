"use strict";
var vmModule = require("./testtab-view-model");
var vm = new vmModule.viewModel();
function onNavigatedTo(args) {
    var page = args.object;
    page.bindingContext = vm;
    vm.loadData();
}
exports.onNavigatedTo = onNavigatedTo;
;
//# sourceMappingURL=testtab.js.map