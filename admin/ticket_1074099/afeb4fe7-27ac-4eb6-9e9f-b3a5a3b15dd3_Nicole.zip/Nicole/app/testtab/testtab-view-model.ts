import {ObservableArray} from "data/observable-array";
import {Observable} from "data/observable";

export class viewModel extends Observable{

    constructor() {
        super();
    }

    public loadData() {
 
        //Tab 1
        var data1 = [
            {description: "aaa"},
            {description: "bbb"},
            {description: "ccc"},
        ];
        var arr1 = new ObservableArray();
        data1.forEach(function(entry){
            arr1.push(entry);
        });
        this.set("rows1", arr1);

        //Tab 2
        var data2 = [
            {description: "ddd"},
            {description: "eee"},
            {description: "fff"},
        ];
        var arr2 = new ObservableArray();
        data2.forEach(function(entry){
            arr2.push(entry);
        });
        this.set("rows2", arr2);
    }

}