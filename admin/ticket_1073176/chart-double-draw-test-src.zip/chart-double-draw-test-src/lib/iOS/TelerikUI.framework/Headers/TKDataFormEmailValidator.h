//
//  TKDataFormMailValidator.h
//  TelerikUI
//
//  Copyright © 2016 Telerik. All rights reserved.
//

#import "TKDataFormPropertyValidator.h"

@interface TKDataFormEmailValidator : TKDataFormPropertyValidator

@end
