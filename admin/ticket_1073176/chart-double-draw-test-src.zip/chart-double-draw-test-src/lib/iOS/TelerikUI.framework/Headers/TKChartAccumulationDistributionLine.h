//
//  TKChartAccumulationDistributionLine.h
//  TelerikUI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

#import "TKChartFinancialIndicator.h"

/**
 Represents Accumulation Distribution Line indicator. Desn't have any specific properties.
 */
@interface TKChartAccumulationDistributionLine : TKChartFinancialIndicator

@end
