//
//  TKSideDrawerDefaultTheme.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKTheme.h"

/**
 @discussion TKSideDrawer's default theme.
 */
@interface TKSideDrawerDefaultTheme : TKTheme

@end
