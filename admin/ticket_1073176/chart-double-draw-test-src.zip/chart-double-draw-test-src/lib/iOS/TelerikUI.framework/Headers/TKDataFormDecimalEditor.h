//
//  TKDataFormDecimalEditor.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKDataFormTextFieldEditor.h"

@interface TKDataFormDecimalEditor : TKDataFormTextFieldEditor

@end
