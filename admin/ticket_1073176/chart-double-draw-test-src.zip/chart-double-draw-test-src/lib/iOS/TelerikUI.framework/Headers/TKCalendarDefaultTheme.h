//
//  TKCalendarDefaultTheme.h
//  Telerik UI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

/**
 @discussion The default theme for TKCalendar.
 */
@interface TKCalendarDefaultTheme : TKTheme

@end
