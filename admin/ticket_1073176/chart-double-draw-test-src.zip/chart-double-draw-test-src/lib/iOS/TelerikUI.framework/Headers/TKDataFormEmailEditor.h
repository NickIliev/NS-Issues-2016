//
//  TKDataFormEmailEditor.h
//  TelerikUI
//
//  Copyright © 2015 Telerik. All rights reserved.
//

#import "TKDataFormTextFieldEditor.h"

@interface TKDataFormEmailEditor : TKDataFormTextFieldEditor

@end
