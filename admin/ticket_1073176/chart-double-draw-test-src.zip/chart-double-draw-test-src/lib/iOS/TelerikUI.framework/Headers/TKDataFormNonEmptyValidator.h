//
//  TKDataFormNonEmptyValidator.h
//  TelerikUI
//
//  Copyright © 2016 Telerik. All rights reserved.
//

#import "TKDataFormPropertyValidator.h"

@interface TKDataFormNonEmptyValidator : TKDataFormPropertyValidator

@end
