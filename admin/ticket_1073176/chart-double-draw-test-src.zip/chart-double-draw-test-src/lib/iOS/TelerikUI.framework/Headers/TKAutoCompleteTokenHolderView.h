//
//  TKAutoCompleteTokenHolderView.h
//  TelerikUI
//
//  Copyright © 2015 Telerik. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 The view in which the tokens are being aligned.
 */
@interface TKAutoCompleteTokenHolderView : UIScrollView

@end
