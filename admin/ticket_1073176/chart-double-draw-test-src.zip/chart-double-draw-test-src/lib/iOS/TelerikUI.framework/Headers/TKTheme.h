//
//  TKTheme.h
//  TelerikUI
//
//  Copyright (c) 2013 Telerik. All rights reserved.
//

/**
 @discussion Represents the theme of a stylable object.
 */
@interface TKTheme : NSObject

@end
