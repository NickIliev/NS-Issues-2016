//
//  TKChartCandlestickBar.h
//  TelerikUI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

#import "TKChartOhlcBar.h"

@interface TKChartCandlestickBar : TKChartOhlcBar

@end
