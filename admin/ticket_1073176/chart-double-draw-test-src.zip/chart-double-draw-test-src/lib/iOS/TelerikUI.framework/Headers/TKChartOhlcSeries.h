//
//  TKChartOhlcSeries.h
//  TelerikUI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

#import "TKChartColumnSeries.h"

/**
 Represents a TKChart OHLC series.
 */
@interface TKChartOhlcSeries : TKChartColumnSeries

@end
