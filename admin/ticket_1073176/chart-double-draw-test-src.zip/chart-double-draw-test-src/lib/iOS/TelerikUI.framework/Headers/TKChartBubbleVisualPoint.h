//
//  TKChartBubbleVisualPoint.h
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

#import "TKChartVisualPoint.h"

@interface TKChartBubbleVisualPoint : TKChartVisualPoint

@property (nonatomic) CGFloat diameter;

@end
