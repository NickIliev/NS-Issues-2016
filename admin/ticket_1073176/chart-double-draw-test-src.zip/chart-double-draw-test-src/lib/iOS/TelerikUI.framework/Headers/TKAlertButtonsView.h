//
//  TKAlertViewButtonsView.h
//  AlertView
//

//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKView.h"

/**
 Represents the buttons area of an alert defined in TKAlert object.
 */
@interface TKAlertButtonsView : TKView

@end
