//
//  TKImageView.h
//  TelerikUI
//
//  Copyright © 2015 Telerik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKImageView : UIImageView

@end
