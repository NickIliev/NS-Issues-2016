//
//  TKChartTRIXIndicator.h
//  TelerikUI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

#import "TKChartSimpleMovingAverageIndicator.h"

/**
 Represents TRIX indicator. Doesn't have any specific properties.
 */
@interface TKChartTRIXIndicator : TKChartSimpleMovingAverageIndicator

@end
