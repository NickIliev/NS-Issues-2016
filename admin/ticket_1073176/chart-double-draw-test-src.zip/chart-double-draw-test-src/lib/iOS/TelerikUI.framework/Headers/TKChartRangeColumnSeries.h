//
//  TKChartRangeColumnSeries.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKChartColumnSeries.h"

@interface TKChartRangeColumnSeries : TKChartColumnSeries

@end
