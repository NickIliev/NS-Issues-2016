//
//  TKChartRangeBarSeries.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKChartBarSeries.h"

@interface TKChartRangeBarSeries : TKChartBarSeries

@end
