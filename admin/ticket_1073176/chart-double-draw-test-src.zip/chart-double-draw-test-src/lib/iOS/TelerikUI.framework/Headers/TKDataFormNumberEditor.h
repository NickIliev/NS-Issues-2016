//
//  TKDataFormNumberEditor.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKDataFormTextFieldEditor.h"

@interface TKDataFormNumberEditor : TKDataFormTextFieldEditor

@property (nonatomic, strong) NSNumberFormatter *formatter;

@end
