//
//  TKCalendarSquareTheme.h
//  Telerik UI
//
//  Copyright (c) 2014 Telerik. All rights reserved.
//

/**
 @discussion A theme for TKCalendar designed for iPad.
 */
@interface TKCalendarIPadTheme : TKTheme

@end
