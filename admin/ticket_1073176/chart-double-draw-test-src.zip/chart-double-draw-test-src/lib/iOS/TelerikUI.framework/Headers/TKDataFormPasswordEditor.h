//
//  TKDataFormPasswordEditor.h
//  TelerikUI
//
//  Copyright © 2015 Telerik. All rights reserved.
//

#import "TKDataFormTextFieldEditor.h"

@interface TKDataFormPasswordEditor : TKDataFormTextFieldEditor

@end
