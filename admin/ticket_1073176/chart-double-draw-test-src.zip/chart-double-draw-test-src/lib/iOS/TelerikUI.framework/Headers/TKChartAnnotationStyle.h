//
//  TKChartAnnotationStyle.h
//  TelerikUI
//
//  Copyright (c) 2013 Telerik. All rights reserved.
//

#import "TKStyleNode.h"

/**
 The base annotation style class
 */
@interface TKChartAnnotationStyle : TKStyleNode

@end
