//
//  TKDataFormPhoneValidator.h
//  TelerikUI
//
//  Copyright © 2016 Telerik. All rights reserved.
//

#import "TKDataFormPropertyValidator.h"

@interface TKDataFormPhoneValidator : TKDataFormPropertyValidator

@end
