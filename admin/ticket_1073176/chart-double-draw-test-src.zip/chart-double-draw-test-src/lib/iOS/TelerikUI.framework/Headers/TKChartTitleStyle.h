//
//  TKChartTitleStyle.h
//  TelerikUI
//
//  Copyright (c) 2013 Telerik. All rights reserved.
//

#import "TKStyleNode.h"

/**
 Represents the TKChart title style.
 */
@interface TKChartTitleStyle : TKStyleNode

@end
