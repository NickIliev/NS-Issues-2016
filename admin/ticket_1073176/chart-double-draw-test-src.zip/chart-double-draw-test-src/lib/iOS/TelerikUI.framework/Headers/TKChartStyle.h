//
//  TKChartStyle.h
//  TelerikUI
//
//  Copyright (c) 2013 Telerik. All rights reserved.
//

#import "TKStyleNode.h"

/**
 * @discussion Represents the TKChart style.
 */
@interface TKChartStyle : TKStyleNode

@end
