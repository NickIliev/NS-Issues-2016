//
//  TKAutoCompleteSuggestionCell.h
//  TelerikUI
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import "TKListViewCell.h"

/**
 The default cell used in the TKSuggestionListView.
 */
@interface TKAutoCompleteSuggestionCell : TKListViewCell

@end
