"use strict";
var viewModelBaseModule = require('../common/view-model-base');
var trace = require('trace');
var ChartViewModelBase = (function (_super) {
    __extends(ChartViewModelBase, _super);
    function ChartViewModelBase() {
        _super.call(this);
        this._chartDataSource = [];
    }
    Object.defineProperty(ChartViewModelBase.prototype, "chartDataSource", {
        get: function () {
            return this._chartDataSource;
        },
        set: function (v) {
            this._chartDataSource = v;
            this.notifyPropertyChange("chartDataSource", v);
        },
        enumerable: true,
        configurable: true
    });
    return ChartViewModelBase;
}(viewModelBaseModule.ViewModelBase));
exports.ChartViewModelBase = ChartViewModelBase;
//# sourceMappingURL=chart-view-model-base.js.map