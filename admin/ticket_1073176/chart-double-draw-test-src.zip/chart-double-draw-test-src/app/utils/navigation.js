/*
This small utility module will handle the navigation between pages
*/
"use strict";
var frameModule = require('ui/frame');
function navigate(navigationEntry) {
    var topmost = frameModule.topmost();
    topmost.navigate(navigationEntry);
}
exports.navigate = navigate;
function goBack() {
    var topmost = frameModule.topmost();
    topmost.goBack();
}
exports.goBack = goBack;
function getCurrentPageId() {
    var topmost = frameModule.topmost();
    return topmost.currentEntry.moduleName;
}
exports.getCurrentPageId = getCurrentPageId;
//# sourceMappingURL=navigation.js.map