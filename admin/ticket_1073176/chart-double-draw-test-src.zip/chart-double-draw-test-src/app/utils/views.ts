export module Views {
    export let main = "pages/main/main";
    export let temperatureChart = "pages/temperature-chart/temperature-chart"
}