"use strict";
var Views;
(function (Views) {
    Views.main = "pages/main/main";
    Views.temperatureChart = "pages/temperature-chart/temperature-chart";
})(Views = exports.Views || (exports.Views = {}));
//# sourceMappingURL=views.js.map