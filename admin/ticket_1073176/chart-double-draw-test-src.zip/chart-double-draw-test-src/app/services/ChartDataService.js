"use strict";
var trace = require('trace');
var ChartDataService = (function () {
    function ChartDataService() {
        console.log('- ChartDataService created.');
        this._chartData = [];
        this._lastMeasurementTs = null;
    }
    ChartDataService.prototype.add = function (currentMeasurement, totalMeasurementCount, deviceState) {
        if (this._lastMeasurementTs == null || deviceState.ts.getTime() > this._lastMeasurementTs.getTime()) {
            this._lastMeasurementTs = deviceState.ts;
            this._chartData.push(deviceState);
        }
        this._dataComplete = currentMeasurement == totalMeasurementCount;
        if (this._dataComplete && this._onComplete) {
            console.log('- call onComplete callback.');
            this._onComplete(this._chartData);
        }
    };
    ChartDataService.prototype.chartData = function () {
        return this._chartData;
    };
    ChartDataService.prototype.clear = function () {
        this._chartData.splice(0, this._chartData.length);
        this._dataComplete = false;
        this._lastMeasurementTs = null;
    };
    ChartDataService.prototype.setOnCompleteCb = function (cb) {
        this._onComplete = cb;
    };
    return ChartDataService;
}());
exports.ChartDataService = ChartDataService;
exports.chartDataService = new ChartDataService();
//# sourceMappingURL=ChartDataService.js.map