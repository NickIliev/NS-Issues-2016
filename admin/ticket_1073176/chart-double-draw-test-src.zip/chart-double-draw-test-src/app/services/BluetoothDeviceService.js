"use strict";
var ChartDataService_1 = require('./ChartDataService');
var DeviceState_1 = require('../models/DeviceState');
var moment = require('moment');
var timer = require("timer");
var BluetoothDeviceService = (function () {
    function BluetoothDeviceService() {
        this._deviceStates = [];
        for (var _i = 0; _i < 100; _i++) {
            this._deviceStates.push(new DeviceState_1.DeviceState(_i, moment().add(_i, 'hour').toDate()));
        }
    }
    BluetoothDeviceService.prototype.notifyMeasurementHistory = function (deviceUUID) {
        var that = this;
        var totalMessageCount = this._deviceStates.length - 1;
        /*
        for (var _i = 0; _i < this._deviceStates.length; _i++) {
            this.simulateDataFetch(_i, totalMessageCount, this._deviceStates[_i])
        }*/
        var loop = 0;
        var looper = function () {
            console.log('Received measurement: ' + loop);
            if (loop < that._deviceStates.length) {
                ChartDataService_1.chartDataService.add(loop, totalMessageCount, that._deviceStates[loop]);
                loop++;
            }
            else {
                console.log('All measurements received.');
                return;
            }
            setTimeout(looper, 10);
        };
        looper();
    };
    BluetoothDeviceService.prototype.simulateDataFetch = function (messageIndex, totalMessageCount, deviceState) {
        timer.setTimeout(function () {
        }, 1000);
    };
    BluetoothDeviceService.prototype.stopNotifyMeasurementHistory = function (deviceUUID) {
        return new Promise(function (resolve, reject) {
            console.log('Stop notify measurement history');
        });
    };
    BluetoothDeviceService.prototype.sleep = function (time) {
        return new Promise(function (resolve) { return timer.setTimeout(function () {
            console.log('resolve sleep');
            resolve();
        }, time); });
    };
    return BluetoothDeviceService;
}());
exports.BluetoothDeviceService = BluetoothDeviceService;
exports.btDeviceService = new BluetoothDeviceService();
//# sourceMappingURL=BluetoothDeviceService.js.map