"use strict";
var DeviceState = (function () {
    function DeviceState(temperature, ts) {
        this._temperature = temperature;
        this._ts = ts;
    }
    Object.defineProperty(DeviceState.prototype, "temperature", {
        get: function () {
            return this._temperature;
        },
        set: function (v) {
            this._temperature = v;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DeviceState.prototype, "ts", {
        get: function () {
            return this._ts;
        },
        set: function (v) {
            this._ts = v;
        },
        enumerable: true,
        configurable: true
    });
    return DeviceState;
}());
exports.DeviceState = DeviceState;
//# sourceMappingURL=DeviceState.js.map