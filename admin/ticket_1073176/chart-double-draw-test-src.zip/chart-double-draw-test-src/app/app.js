"use strict";
var applicationModule = require('application');
var viewsModule = require('./utils/views');
applicationModule.onLaunch = function (context) {
    applicationModule.mainEntry = {
        moduleName: viewsModule.Views.main,
        backstackVisible: true,
        context: null
    };
};
applicationModule.start();
//# sourceMappingURL=app.js.map