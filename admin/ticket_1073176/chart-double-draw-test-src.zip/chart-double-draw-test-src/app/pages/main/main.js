"use strict";
var navigationModule = require('../../utils/navigation');
var views_1 = require('../../utils/views');
var main_view_model_1 = require('./main-view-model');
var viewModel;
var page;
function navigatingTo(args) {
    page = args.object;
    viewModel = new main_view_model_1.MainViewModel();
}
exports.navigatingTo = navigatingTo;
function showTemperatureChart() {
    navigationModule.navigate({
        moduleName: views_1.Views.temperatureChart,
        backstackVisible: true
    });
}
exports.showTemperatureChart = showTemperatureChart;
function navigatingFrom() {
    console.log('main navigating from.....');
}
exports.navigatingFrom = navigatingFrom;
//# sourceMappingURL=main.js.map