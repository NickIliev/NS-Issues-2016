import * as viewModelBaseModule from '../../common/view-model-base'

class MainViewModel extends viewModelBaseModule.ViewModelBase {

    constructor() {
        super()
    }

}

export { MainViewModel }