"use strict";
var viewModelBaseModule = require('../../common/view-model-base');
var MainViewModel = (function (_super) {
    __extends(MainViewModel, _super);
    function MainViewModel() {
        _super.call(this);
    }
    return MainViewModel;
}(viewModelBaseModule.ViewModelBase));
exports.MainViewModel = MainViewModel;
//# sourceMappingURL=main-view-model.js.map