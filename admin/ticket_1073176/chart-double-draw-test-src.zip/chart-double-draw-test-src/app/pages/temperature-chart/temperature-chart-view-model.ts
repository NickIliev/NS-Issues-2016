import { ChartViewModelBase } from '../../common/chart-view-model-base'
import { DeviceState } from '../../models/DeviceState'

class TemperatureChartViewModel extends ChartViewModelBase {

    constructor() {
        super();
    }

}

export { TemperatureChartViewModel }