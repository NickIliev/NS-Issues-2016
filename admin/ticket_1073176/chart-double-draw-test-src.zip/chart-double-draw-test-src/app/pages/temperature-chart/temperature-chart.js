"use strict";
var temperature_chart_view_model_1 = require('./temperature-chart-view-model');
var BluetoothDeviceService_1 = require('../../services/BluetoothDeviceService');
var ChartDataService_1 = require('../../services/ChartDataService');
var viewModel;
var page;
function navigatingTo(args) {
    console.log('chart navigatingTo');
    page = args.object;
    viewModel = new temperature_chart_view_model_1.TemperatureChartViewModel();
    page.bindingContext = viewModel;
    if (ChartDataService_1.chartDataService.chartData().length > 0) {
        viewModel.chartDataSource = ChartDataService_1.chartDataService.chartData();
    }
    else {
        viewModel.beginLoading();
        BluetoothDeviceService_1.btDeviceService.notifyMeasurementHistory('foo-bar');
        viewModel.endLoading();
    }
    ChartDataService_1.chartDataService.setOnCompleteCb(onComplete);
}
exports.navigatingTo = navigatingTo;
function navigatingFrom() {
    ChartDataService_1.chartDataService.clear();
}
exports.navigatingFrom = navigatingFrom;
var onComplete = function (result) {
    console.log('Calling onComplete with:' + result.length + 'device states');
    viewModel.chartDataSource = result;
};
//# sourceMappingURL=temperature-chart.js.map