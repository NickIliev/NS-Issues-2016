"use strict";
var chart_view_model_base_1 = require('../../common/chart-view-model-base');
var TemperatureChartViewModel = (function (_super) {
    __extends(TemperatureChartViewModel, _super);
    function TemperatureChartViewModel() {
        _super.call(this);
    }
    return TemperatureChartViewModel;
}(chart_view_model_base_1.ChartViewModelBase));
exports.TemperatureChartViewModel = TemperatureChartViewModel;
//# sourceMappingURL=temperature-chart-view-model.js.map